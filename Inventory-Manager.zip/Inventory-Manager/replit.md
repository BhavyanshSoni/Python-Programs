# StockIQ — Inventory Management System

A professional, full-stack inventory management web app with a dark command-center aesthetic.

## Run & Operate

- `pnpm --filter @workspace/api-server run dev` — run the API server (port 8080)
- `pnpm --filter @workspace/inventory-app run dev` — run the frontend (port 24449)
- `pnpm run typecheck` — full typecheck across all packages
- `pnpm run build` — typecheck + build all packages
- `pnpm --filter @workspace/api-spec run codegen` — regenerate API hooks and Zod schemas from the OpenAPI spec
- `pnpm --filter @workspace/db run push` — push DB schema changes (dev only)
- Required env: `DATABASE_URL` — Postgres connection string (auto-provisioned)

## Stack

- pnpm workspaces, Node.js 24, TypeScript 5.9
- Frontend: React + Vite, Tailwind CSS v4, Recharts, Framer Motion, shadcn/ui, react-hook-form + zod
- API: Express 5
- DB: PostgreSQL + Drizzle ORM
- Validation: Zod (`zod/v4`), `drizzle-zod`
- API codegen: Orval (from OpenAPI spec)
- Build: esbuild (CJS bundle)

## Where things live

- `lib/api-spec/openapi.yaml` — Single source of truth for all API contracts
- `lib/db/src/schema/` — Drizzle table definitions (categories, suppliers, products, inventory_movements, transactions)
- `artifacts/api-server/src/routes/` — Express route handlers (categories, suppliers, products, inventory, transactions, dashboard, reports)
- `artifacts/inventory-app/src/` — React frontend (pages: Dashboard, Products, Inventory, Suppliers, Transactions, Reports)
- `lib/api-client-react/src/generated/` — Generated React Query hooks (do not edit)
- `lib/api-zod/src/generated/` — Generated Zod schemas for backend validation (do not edit)

## Architecture decisions

- Contract-first: OpenAPI spec gates codegen, which gates both frontend hooks and backend validators
- Single API server serves all routes under `/api` prefix
- Frontend is a pure SPA at `/` with wouter for client-side routing
- Inventory movements and transactions both update product quantity atomically in the route handler
- Dashboard stats use SQL aggregates (no caching layer needed at this scale)

## Product

- **Dashboard**: Real-time stats (total value, product count, stock levels), area chart trend, donut category breakdown, recent activity feed
- **Products**: Full CRUD with search/filter by category and stock status, stock badges (in stock / low stock / out of stock)
- **Inventory Movements**: Stock in / stock out / adjustment records with history log
- **Suppliers**: Contact management with full CRUD
- **Transactions**: Purchase and sale records with auto quantity adjustment
- **Reports**: Low stock report, inventory value by category (bar chart), top products by revenue

## User preferences

_Populate as you build — explicit user instructions worth remembering across sessions._

## Gotchas

- After any OpenAPI spec change: run `pnpm --filter @workspace/api-spec run codegen` before touching route handlers
- `unitPrice` and `totalAmount` are stored as `numeric` in Postgres — always `String(value)` when inserting, `Number(value)` when reading
- Express 5: use `req.params.id` with `Array.isArray` guard, `/{*splat}` for wildcards, `Promise<void>` on async handlers
- Never use `console.log` in server code — use `req.log` in handlers, `logger` for app-level logs

## Pointers

- See the `pnpm-workspace` skill for workspace structure, TypeScript setup, and package details
