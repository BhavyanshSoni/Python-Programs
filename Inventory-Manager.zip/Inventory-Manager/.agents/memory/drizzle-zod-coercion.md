---
name: Drizzle→Zod type coercion
description: Drizzle ORM returns numeric columns as strings and timestamp columns as Date objects, but Orval-generated Zod schemas expect strict number/string — you must coerce before calling .parse().
---

## The rule

Any route that calls `ZodSchema.parse(dbRows)` must first coerce the rows to match the generated Zod types. Orval does NOT generate `z.coerce.number()` or `z.coerce.date()` — it generates strict `z.number()` and `z.string()`.

## Affected column types

| Postgres type | Drizzle JS return | Zod schema expects | Fix |
|---|---|---|---|
| `numeric` / `decimal` | `string` (e.g. `"199.99"`) | `number` | `Number(r.unitPrice)` |
| `timestamp` | `Date` object | `string` | `r.createdAt.toISOString()` |

## How to apply

Create a `coerceXxx(r: any)` helper at the top of each route file (or in `src/lib/coerce.ts`) and pipe rows through it before calling `.parse()`:

```typescript
import { toISOString, toNum } from "../lib/coerce";

function coerceProduct(r: any) {
  return {
    ...r,
    unitPrice: toNum(r.unitPrice),
    gstPercent: toNum(r.gstPercent, 18),
    createdAt: toISOString(r.createdAt) ?? "",
    updatedAt: toISOString(r.updatedAt),
  };
}

// Usage
res.json(ListProductsResponse.parse(rows.map(coerceProduct)));
```

The shared helpers live in `artifacts/api-server/src/lib/coerce.ts`.

**Why:** Postgres `numeric` type preserves arbitrary precision, so the `pg` driver returns it as a string to avoid JS floating-point loss. Orval reads OpenAPI `type: number` and generates `z.number()` with no coercion. These two behaviors are incompatible without an explicit mapping step.
