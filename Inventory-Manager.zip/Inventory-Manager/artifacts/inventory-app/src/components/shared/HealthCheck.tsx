import { useHealthCheck } from "@workspace/api-client-react";
import { useEffect } from "react";

export function HealthCheck() {
  const { data } = useHealthCheck();
  
  useEffect(() => {
    if (data) {
      document.documentElement.classList.add("dark");
    }
  }, [data]);

  return null;
}
