import { Badge } from "@/components/ui/badge";

export function StatusBadge({ type, label }: { type: "IN" | "OUT" | "ADJUSTMENT" | "purchase" | "sale" | "low_stock" | "out_of_stock" | "in_stock", label?: string }) {
  let colorClass = "";
  let defaultLabel = label;

  switch (type) {
    case "IN":
    case "in_stock":
    case "sale":
      colorClass = "bg-emerald-500/15 text-emerald-500 hover:bg-emerald-500/25 border-emerald-500/20";
      defaultLabel = defaultLabel || (type === "IN" ? "Stock In" : type === "sale" ? "Sale" : "In Stock");
      break;
    case "OUT":
    case "out_of_stock":
      colorClass = "bg-red-500/15 text-red-500 hover:bg-red-500/25 border-red-500/20";
      defaultLabel = defaultLabel || (type === "OUT" ? "Stock Out" : "Out of Stock");
      break;
    case "ADJUSTMENT":
    case "low_stock":
      colorClass = "bg-amber-500/15 text-amber-500 hover:bg-amber-500/25 border-amber-500/20";
      defaultLabel = defaultLabel || (type === "ADJUSTMENT" ? "Adjustment" : "Low Stock");
      break;
    case "purchase":
      colorClass = "bg-blue-500/15 text-blue-500 hover:bg-blue-500/25 border-blue-500/20";
      defaultLabel = defaultLabel || "Purchase";
      break;
  }

  return (
    <Badge variant="outline" className={`font-mono text-[10px] uppercase tracking-wider px-2 py-0.5 rounded-sm ${colorClass}`}>
      {defaultLabel}
    </Badge>
  );
}
