import { Link, useLocation } from "wouter";
import { 
  Box, 
  LayoutDashboard, 
  Package, 
  ArrowRightLeft, 
  Users, 
  History, 
  BarChart3, 
  Settings
} from "lucide-react";
import { motion } from "framer-motion";

const routes = [
  { path: "/", label: "Dashboard", icon: LayoutDashboard },
  { path: "/products", label: "Products", icon: Package },
  { path: "/inventory", label: "Movements", icon: ArrowRightLeft },
  { path: "/suppliers", label: "Suppliers", icon: Users },
  { path: "/transactions", label: "Transactions", icon: History },
  { path: "/reports", label: "Reports", icon: BarChart3 },
];

export function Sidebar() {
  const [location] = useLocation();

  return (
    <div className="w-[240px] flex-shrink-0 bg-sidebar border-r border-sidebar-border h-screen flex flex-col sticky top-0">
      <div className="p-6 flex items-center gap-3">
        <div className="w-8 h-8 rounded bg-primary/20 flex items-center justify-center text-primary">
          <Box className="w-5 h-5" />
        </div>
        <span className="font-bold text-lg tracking-tight text-foreground">StockIQ</span>
      </div>

      <nav className="flex-1 px-4 py-2 space-y-1">
        {routes.map((route) => {
          const isActive = location === route.path;
          return (
            <Link key={route.path} href={route.path}>
              <div className={`flex items-center gap-3 px-3 py-2.5 rounded-md cursor-pointer transition-colors relative group ${isActive ? "text-primary" : "text-muted-foreground hover:text-foreground hover:bg-white/5"}`}>
                {isActive && (
                  <motion.div 
                    layoutId="active-sidebar-nav" 
                    className="absolute inset-0 bg-primary/10 rounded-md" 
                    initial={false} 
                    transition={{ type: "spring", stiffness: 300, damping: 30 }} 
                  />
                )}
                <route.icon className="w-4 h-4 z-10" />
                <span className="text-sm font-medium z-10">{route.label}</span>
              </div>
            </Link>
          );
        })}
      </nav>

      <div className="p-4 border-t border-sidebar-border">
        <Link href="/settings">
          <div className={`flex items-center gap-3 px-3 py-2.5 rounded-md cursor-pointer transition-colors relative ${location === "/settings" ? "text-primary" : "text-muted-foreground hover:text-foreground hover:bg-white/5"}`}>
            {location === "/settings" && (
              <motion.div
                layoutId="active-sidebar-nav"
                className="absolute inset-0 bg-primary/10 rounded-md"
                initial={false}
                transition={{ type: "spring", stiffness: 300, damping: 30 }}
              />
            )}
            <Settings className="w-4 h-4 z-10" />
            <span className="text-sm font-medium z-10">Settings</span>
          </div>
        </Link>
      </div>
    </div>
  );
}
