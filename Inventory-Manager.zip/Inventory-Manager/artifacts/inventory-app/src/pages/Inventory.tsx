import { useState } from "react";
import { useForm } from "react-hook-form";
import { z } from "zod";
import { zodResolver } from "@hookform/resolvers/zod";
import {
  useListInventoryMovements, useCreateInventoryMovement,
  useListProducts, getListInventoryMovementsQueryKey, getListProductsQueryKey,
  useGetRecentActivity, getGetRecentActivityQueryKey,
} from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { formatNumber, formatDate } from "@/lib/formatters";
import { StatusBadge } from "@/components/shared/StatusBadge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { Plus, Search, RefreshCw, ArrowUpCircle, ArrowDownCircle, SlidersHorizontal } from "lucide-react";

const movementSchema = z.object({
  productId: z.coerce.number().int().positive("Please select a product"),
  movementType: z.enum(["stock_in", "stock_out", "adjustment"], { required_error: "Select movement type" }),
  quantity: z.coerce.number().int("Must be a whole number").positive("Quantity must be greater than 0"),
  reason: z.string().optional(),
  notes: z.string().optional(),
});
type MovementForm = z.infer<typeof movementSchema>;

type TypeFilter = "all" | "stock_in" | "stock_out" | "adjustment";

export default function Inventory() {
  const queryClient = useQueryClient();
  const [dialogOpen, setDialogOpen] = useState(false);
  const [typeFilter, setTypeFilter] = useState<TypeFilter>("all");
  const [search, setSearch] = useState("");

  const { data: movements, isLoading } = useListInventoryMovements({
    query: {
      queryKey: getListInventoryMovementsQueryKey({ limit: 200 }),
      params: { limit: 200 },
    },
  });

  const { data: activities } = useGetRecentActivity({
    query: {
      queryKey: getGetRecentActivityQueryKey({ limit: 10 }),
      params: { limit: 10 },
    },
  });

  const { data: products } = useListProducts({ query: { queryKey: getListProductsQueryKey() } });
  const createMovement = useCreateInventoryMovement();

  const { register, handleSubmit, reset, setValue, watch, formState: { errors } } = useForm<MovementForm>({
    resolver: zodResolver(movementSchema),
    defaultValues: { quantity: 1, movementType: "stock_in" },
  });

  const filtered = (movements ?? []).filter(m => {
    if (typeFilter !== "all" && m.movementType !== typeFilter) return false;
    if (search && !m.productName?.toLowerCase().includes(search.toLowerCase())) return false;
    return true;
  });

  const onSubmit = (data: MovementForm) => {
    createMovement.mutate({ data }, {
      onSuccess: () => {
        toast.success("Inventory movement recorded");
        queryClient.invalidateQueries({ queryKey: getListInventoryMovementsQueryKey() });
        queryClient.invalidateQueries({ queryKey: getListProductsQueryKey() });
        queryClient.invalidateQueries({ queryKey: getGetRecentActivityQueryKey() });
        setDialogOpen(false);
        reset();
      },
      onError: (e: any) => {
        const msg = e?.response?.data?.error ?? e?.message ?? "Failed to record movement";
        toast.error(msg);
      },
    });
  };

  const stockInCount = (movements ?? []).filter(m => m.movementType === "stock_in").length;
  const stockOutCount = (movements ?? []).filter(m => m.movementType === "stock_out").length;

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-3xl font-bold tracking-tight">Inventory Movements</h1>
        <Button size="sm" className="bg-emerald-600 text-white hover:bg-emerald-700" onClick={() => setDialogOpen(true)}>
          <Plus className="w-4 h-4 mr-1.5" /> Record Movement
        </Button>
      </div>

      {/* SUMMARY CARDS */}
      <div className="grid grid-cols-3 gap-4">
        <Card className="glass-card">
          <CardContent className="p-4 flex items-center gap-3">
            <div className="p-2 rounded-md bg-emerald-500/20 text-emerald-400"><ArrowUpCircle className="w-4 h-4" /></div>
            <div><p className="text-xs text-muted-foreground">Total Stock In</p><p className="text-lg font-bold">{stockInCount}</p></div>
          </CardContent>
        </Card>
        <Card className="glass-card">
          <CardContent className="p-4 flex items-center gap-3">
            <div className="p-2 rounded-md bg-red-500/20 text-red-400"><ArrowDownCircle className="w-4 h-4" /></div>
            <div><p className="text-xs text-muted-foreground">Total Stock Out</p><p className="text-lg font-bold">{stockOutCount}</p></div>
          </CardContent>
        </Card>
        <Card className="glass-card">
          <CardContent className="p-4 flex items-center gap-3">
            <div className="p-2 rounded-md bg-primary/20 text-primary"><SlidersHorizontal className="w-4 h-4" /></div>
            <div><p className="text-xs text-muted-foreground">Total Movements</p><p className="text-lg font-bold">{movements?.length ?? 0}</p></div>
          </CardContent>
        </Card>
      </div>

      {/* FILTERS */}
      <div className="flex items-center gap-3 bg-card p-3 rounded-lg border border-border">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input placeholder="Filter by product name..." className="pl-9 bg-background border-input h-9" value={search} onChange={e => setSearch(e.target.value)} />
        </div>
        <div className="w-[180px]">
          <Select value={typeFilter} onValueChange={v => setTypeFilter(v as TypeFilter)}>
            <SelectTrigger className="bg-background border-input h-9"><SelectValue /></SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Types</SelectItem>
              <SelectItem value="stock_in">Stock In</SelectItem>
              <SelectItem value="stock_out">Stock Out</SelectItem>
              <SelectItem value="adjustment">Adjustment</SelectItem>
            </SelectContent>
          </Select>
        </div>
        <span className="text-xs text-muted-foreground">{filtered.length} records</span>
      </div>

      {/* MOVEMENTS TABLE */}
      <Card className="glass-card overflow-hidden">
        <div className="overflow-x-auto">
          <Table>
            <TableHeader className="bg-muted/50">
              <TableRow className="border-border">
                <TableHead>Date & Time</TableHead>
                <TableHead>Product</TableHead>
                <TableHead>Type</TableHead>
                <TableHead className="text-right">Qty</TableHead>
                <TableHead className="text-right">Before → After</TableHead>
                <TableHead>Reason</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {isLoading ? (
                Array.from({ length: 5 }).map((_, i) => (
                  <TableRow key={i} className="border-border">
                    {Array.from({ length: 6 }).map((_, j) => <TableCell key={j}><Skeleton className="h-4 w-full" /></TableCell>)}
                  </TableRow>
                ))
              ) : filtered.length === 0 ? (
                <TableRow><TableCell colSpan={6} className="text-center py-12 text-muted-foreground">No movements recorded</TableCell></TableRow>
              ) : (
                filtered.map(m => (
                  <TableRow key={m.id} className="border-border hover:bg-white/5 transition-colors">
                    <TableCell className="text-xs text-muted-foreground whitespace-nowrap font-mono">{formatDate(m.createdAt)}</TableCell>
                    <TableCell className="font-medium text-sm">{m.productName}</TableCell>
                    <TableCell>
                      <StatusBadge type={m.movementType === "stock_in" ? "IN" : m.movementType === "stock_out" ? "OUT" : "ADJUSTMENT"} />
                    </TableCell>
                    <TableCell className={`text-right font-mono font-semibold text-sm ${m.movementType === "stock_out" ? "text-red-400" : m.movementType === "stock_in" ? "text-emerald-400" : "text-amber-400"}`}>
                      {m.movementType === "stock_out" ? "-" : "+"}{formatNumber(m.quantity)}
                    </TableCell>
                    <TableCell className="text-right font-mono text-xs text-muted-foreground">
                      {m.previousQuantity} → {m.newQuantity}
                    </TableCell>
                    <TableCell className="text-sm text-muted-foreground max-w-[180px] truncate">{m.reason || "—"}</TableCell>
                  </TableRow>
                ))
              )}
            </TableBody>
          </Table>
        </div>
      </Card>

      {/* ACTIVITY LOG SECTION */}
      <Card className="glass-card">
        <CardHeader>
          <CardTitle className="text-sm font-medium text-muted-foreground uppercase tracking-wider flex items-center gap-2">
            <RefreshCw className="w-4 h-4" /> Activity Log
          </CardTitle>
        </CardHeader>
        <CardContent>
          {!activities ? (
            <div className="space-y-3">{[1,2,3].map(i => <Skeleton key={i} className="h-12 w-full" />)}</div>
          ) : (
            <div className="space-y-2">
              {activities.map(a => {
                const isIn = a.type === "stock_in";
                const isOut = a.type === "stock_out";
                return (
                  <div key={a.id} className="flex items-center gap-3 p-2.5 rounded bg-white/4 border border-white/5">
                    <div className={`w-1.5 h-1.5 rounded-full shrink-0 ${isIn ? "bg-emerald-400" : isOut ? "bg-red-400" : "bg-amber-400"}`} />
                    <span className="text-sm text-foreground flex-1">{a.description}</span>
                    {a.quantity && (
                      <span className={`text-xs font-mono font-bold ${isIn ? "text-emerald-400" : isOut ? "text-red-400" : "text-amber-400"}`}>
                        {isIn ? "+" : isOut ? "-" : "±"}{a.quantity} units
                      </span>
                    )}
                    <span className="text-xs text-muted-foreground font-mono shrink-0">{formatDate(a.createdAt)}</span>
                  </div>
                );
              })}
            </div>
          )}
        </CardContent>
      </Card>

      {/* RECORD MOVEMENT DIALOG */}
      <Dialog open={dialogOpen} onOpenChange={o => { if (!o) { setDialogOpen(false); reset(); } }}>
        <DialogContent className="bg-card border-border max-w-md">
          <DialogHeader>
            <DialogTitle>Record Inventory Movement</DialogTitle>
          </DialogHeader>
          <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
            <div className="space-y-1.5">
              <Label>Product <span className="text-destructive">*</span></Label>
              <Select onValueChange={v => setValue("productId", Number(v))}>
                <SelectTrigger className="bg-background border-input"><SelectValue placeholder="Select product" /></SelectTrigger>
                <SelectContent>
                  {products?.map(p => (
                    <SelectItem key={p.id} value={String(p.id)}>
                      {p.name} <span className="text-muted-foreground ml-1">({p.quantity} in stock)</span>
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              {errors.productId && <p className="text-xs text-destructive">{errors.productId.message}</p>}
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-1.5">
                <Label>Movement Type <span className="text-destructive">*</span></Label>
                <Select defaultValue="stock_in" onValueChange={v => setValue("movementType", v as any)}>
                  <SelectTrigger className="bg-background border-input"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="stock_in">Stock In</SelectItem>
                    <SelectItem value="stock_out">Stock Out</SelectItem>
                    <SelectItem value="adjustment">Adjustment</SelectItem>
                  </SelectContent>
                </Select>
                {errors.movementType && <p className="text-xs text-destructive">{errors.movementType.message}</p>}
              </div>
              <div className="space-y-1.5">
                <Label htmlFor="qty">Quantity <span className="text-destructive">*</span></Label>
                <Input id="qty" type="number" min="1" step="1" {...register("quantity")} className="bg-background border-input" />
                {errors.quantity && <p className="text-xs text-destructive">{errors.quantity.message}</p>}
              </div>
            </div>

            <div className="space-y-1.5">
              <Label htmlFor="reason">Reason</Label>
              <Input id="reason" {...register("reason")} placeholder="e.g. Purchase order PO-001, Damaged goods" className="bg-background border-input" />
            </div>

            <div className="space-y-1.5">
              <Label htmlFor="notes">Notes</Label>
              <Input id="notes" {...register("notes")} placeholder="Additional notes (optional)" className="bg-background border-input" />
            </div>

            <DialogFooter>
              <Button type="button" variant="outline" onClick={() => { setDialogOpen(false); reset(); }} className="border-border">Cancel</Button>
              <Button type="submit" disabled={createMovement.isPending} className="bg-emerald-600 hover:bg-emerald-700 text-white">
                {createMovement.isPending ? "Recording..." : "Record Movement"}
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>
    </div>
  );
}
