import { useState } from "react";
import { useForm } from "react-hook-form";
import { z } from "zod";
import { zodResolver } from "@hookform/resolvers/zod";
import {
  useListTransactions, useCreateTransaction,
  useListProducts, useListSuppliers,
  getListTransactionsQueryKey, getListProductsQueryKey,
} from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { formatCurrency, formatDate, formatNumber } from "@/lib/formatters";
import { StatusBadge } from "@/components/shared/StatusBadge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Card, CardContent } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { Plus, Search, TrendingUp, TrendingDown, IndianRupee } from "lucide-react";

const txSchema = z.object({
  type: z.enum(["purchase", "sale"], { required_error: "Select transaction type" }),
  productId: z.coerce.number().int().positive("Please select a product"),
  supplierId: z.union([z.coerce.number().int().positive(), z.literal(0)]).optional().transform(v => v === 0 ? undefined : v),
  quantity: z.coerce.number().int("Must be a whole number").positive("Quantity must be greater than 0"),
  unitPrice: z.coerce.number().positive("Price must be greater than ₹0"),
  referenceNumber: z.string().optional(),
  notes: z.string().optional(),
});
type TxForm = z.infer<typeof txSchema>;

type TxTypeFilter = "all" | "purchase" | "sale";

export default function Transactions() {
  const queryClient = useQueryClient();
  const [search, setSearch] = useState("");
  const [typeFilter, setTypeFilter] = useState<TxTypeFilter>("all");
  const [dialogOpen, setDialogOpen] = useState(false);

  const { data: transactions, isLoading } = useListTransactions({
    query: {
      queryKey: getListTransactionsQueryKey({ type: typeFilter !== "all" ? typeFilter : undefined }),
      params: { type: typeFilter !== "all" ? typeFilter as any : undefined, limit: 200 },
    },
  });
  const { data: products } = useListProducts({ query: { queryKey: getListProductsQueryKey() } });
  const { data: suppliers } = useListSuppliers({ query: { params: {} } });
  const createTx = useCreateTransaction();

  const { register, handleSubmit, reset, setValue, watch, formState: { errors } } = useForm<TxForm>({
    resolver: zodResolver(txSchema),
    defaultValues: { type: "purchase", quantity: 1, unitPrice: 0 },
  });

  const qty = watch("quantity") ?? 0;
  const price = watch("unitPrice") ?? 0;
  const total = (Number(qty) || 0) * (Number(price) || 0);

  const filtered = (transactions ?? []).filter(t =>
    !search || t.productName?.toLowerCase().includes(search.toLowerCase()) || t.referenceNumber?.toLowerCase().includes(search.toLowerCase())
  );

  const totalPurchases = filtered.filter(t => t.type === "purchase").reduce((s, t) => s + Number(t.totalAmount), 0);
  const totalSales = filtered.filter(t => t.type === "sale").reduce((s, t) => s + Number(t.totalAmount), 0);

  const onSubmit = (data: TxForm) => {
    createTx.mutate({ data: data as any }, {
      onSuccess: () => {
        toast.success(`${data.type === "purchase" ? "Purchase" : "Sale"} recorded`);
        queryClient.invalidateQueries({ queryKey: getListTransactionsQueryKey() });
        queryClient.invalidateQueries({ queryKey: getListProductsQueryKey() });
        setDialogOpen(false);
        reset();
      },
      onError: (e: any) => toast.error(e?.response?.data?.error ?? "Failed to record transaction"),
    });
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-3xl font-bold tracking-tight">Transactions</h1>
        <Button size="sm" className="bg-primary text-primary-foreground hover:bg-primary/90" onClick={() => setDialogOpen(true)}>
          <Plus className="w-4 h-4 mr-1.5" /> New Transaction
        </Button>
      </div>

      {/* SUMMARY */}
      <div className="grid grid-cols-3 gap-4">
        <Card className="glass-card">
          <CardContent className="p-4 flex items-center gap-3">
            <div className="p-2 rounded-md bg-blue-500/20 text-blue-400"><TrendingDown className="w-4 h-4" /></div>
            <div><p className="text-xs text-muted-foreground">Total Purchases</p><p className="text-lg font-bold">{formatCurrency(totalPurchases)}</p></div>
          </CardContent>
        </Card>
        <Card className="glass-card">
          <CardContent className="p-4 flex items-center gap-3">
            <div className="p-2 rounded-md bg-emerald-500/20 text-emerald-400"><TrendingUp className="w-4 h-4" /></div>
            <div><p className="text-xs text-muted-foreground">Total Sales</p><p className="text-lg font-bold">{formatCurrency(totalSales)}</p></div>
          </CardContent>
        </Card>
        <Card className="glass-card">
          <CardContent className="p-4 flex items-center gap-3">
            <div className={`p-2 rounded-md ${totalSales - totalPurchases >= 0 ? "bg-emerald-500/20 text-emerald-400" : "bg-red-500/20 text-red-400"}`}>
              <IndianRupee className="w-4 h-4" />
            </div>
            <div>
              <p className="text-xs text-muted-foreground">Net P&L</p>
              <p className={`text-lg font-bold ${totalSales - totalPurchases >= 0 ? "text-emerald-400" : "text-red-400"}`}>{formatCurrency(totalSales - totalPurchases)}</p>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* FILTERS */}
      <div className="flex items-center gap-3 bg-card p-3 rounded-lg border border-border">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input placeholder="Search by product or reference..." className="pl-9 bg-background border-input h-9" value={search} onChange={e => setSearch(e.target.value)} />
        </div>
        <div className="w-[160px]">
          <Select value={typeFilter} onValueChange={v => setTypeFilter(v as TxTypeFilter)}>
            <SelectTrigger className="bg-background border-input h-9"><SelectValue /></SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Types</SelectItem>
              <SelectItem value="purchase">Purchases</SelectItem>
              <SelectItem value="sale">Sales</SelectItem>
            </SelectContent>
          </Select>
        </div>
        <span className="text-xs text-muted-foreground">{filtered.length} transactions</span>
      </div>

      {/* TABLE */}
      <Card className="glass-card overflow-hidden">
        <div className="overflow-x-auto">
          <Table>
            <TableHeader className="bg-muted/50">
              <TableRow className="border-border">
                <TableHead>Date</TableHead>
                <TableHead>Type</TableHead>
                <TableHead>Product</TableHead>
                <TableHead>Supplier</TableHead>
                <TableHead>Reference</TableHead>
                <TableHead className="text-right">Qty</TableHead>
                <TableHead className="text-right">Unit Price</TableHead>
                <TableHead className="text-right">Total</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {isLoading ? (
                Array.from({ length: 5 }).map((_, i) => (
                  <TableRow key={i} className="border-border">
                    {Array.from({ length: 8 }).map((_, j) => <TableCell key={j}><Skeleton className="h-4 w-full" /></TableCell>)}
                  </TableRow>
                ))
              ) : filtered.length === 0 ? (
                <TableRow><TableCell colSpan={8} className="text-center py-12 text-muted-foreground">No transactions found</TableCell></TableRow>
              ) : (
                filtered.map(t => (
                  <TableRow key={t.id} className="border-border hover:bg-white/5 transition-colors">
                    <TableCell className="text-xs text-muted-foreground font-mono whitespace-nowrap">{formatDate(t.createdAt)}</TableCell>
                    <TableCell><StatusBadge type={t.type as any} /></TableCell>
                    <TableCell className="font-medium text-sm">{t.productName}</TableCell>
                    <TableCell className="text-sm text-muted-foreground">{t.supplierName || "—"}</TableCell>
                    <TableCell className="font-mono text-xs text-muted-foreground">{t.referenceNumber || "—"}</TableCell>
                    <TableCell className="text-right font-mono text-sm">{formatNumber(t.quantity)}</TableCell>
                    <TableCell className="text-right font-mono text-sm">{formatCurrency(Number(t.unitPrice))}</TableCell>
                    <TableCell className={`text-right font-mono font-semibold text-sm ${t.type === "sale" ? "text-emerald-400" : "text-blue-400"}`}>
                      {formatCurrency(Number(t.totalAmount))}
                    </TableCell>
                  </TableRow>
                ))
              )}
            </TableBody>
          </Table>
        </div>
      </Card>

      {/* NEW TRANSACTION DIALOG */}
      <Dialog open={dialogOpen} onOpenChange={o => { if (!o) { setDialogOpen(false); reset(); } }}>
        <DialogContent className="bg-card border-border max-w-md">
          <DialogHeader><DialogTitle>New Transaction</DialogTitle></DialogHeader>
          <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-1.5">
                <Label>Type <span className="text-destructive">*</span></Label>
                <Select defaultValue="purchase" onValueChange={v => setValue("type", v as any)}>
                  <SelectTrigger className="bg-background border-input"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="purchase">Purchase</SelectItem>
                    <SelectItem value="sale">Sale</SelectItem>
                  </SelectContent>
                </Select>
                {errors.type && <p className="text-xs text-destructive">{errors.type.message}</p>}
              </div>
              <div className="space-y-1.5">
                <Label>Product <span className="text-destructive">*</span></Label>
                <Select onValueChange={v => {
                  setValue("productId", Number(v));
                  const p = products?.find(x => x.id === Number(v));
                  if (p) setValue("unitPrice", Number(p.unitPrice));
                }}>
                  <SelectTrigger className="bg-background border-input"><SelectValue placeholder="Select product" /></SelectTrigger>
                  <SelectContent>
                    {products?.map(p => <SelectItem key={p.id} value={String(p.id)}>{p.name}</SelectItem>)}
                  </SelectContent>
                </Select>
                {errors.productId && <p className="text-xs text-destructive">{errors.productId.message}</p>}
              </div>
            </div>

            <div className="space-y-1.5">
              <Label>Supplier (for purchases)</Label>
              <Select onValueChange={v => setValue("supplierId", Number(v) as any)}>
                <SelectTrigger className="bg-background border-input"><SelectValue placeholder="Select supplier (optional)" /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="0">None</SelectItem>
                  {suppliers?.map(s => <SelectItem key={s.id} value={String(s.id)}>{s.name}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-1.5">
                <Label>Quantity <span className="text-destructive">*</span></Label>
                <Input type="number" min="1" step="1" {...register("quantity")} className="bg-background border-input" />
                {errors.quantity && <p className="text-xs text-destructive">{errors.quantity.message}</p>}
              </div>
              <div className="space-y-1.5">
                <Label>Unit Price (₹) <span className="text-destructive">*</span></Label>
                <Input type="number" min="0.01" step="0.01" {...register("unitPrice")} className="bg-background border-input" />
                {errors.unitPrice && <p className="text-xs text-destructive">{errors.unitPrice.message}</p>}
              </div>
            </div>

            {total > 0 && (
              <div className="flex items-center justify-between px-3 py-2 bg-primary/10 rounded border border-primary/20">
                <span className="text-sm text-muted-foreground">Total Amount</span>
                <span className="font-bold text-primary font-mono">{formatCurrency(total)}</span>
              </div>
            )}

            <div className="space-y-1.5">
              <Label>Reference Number</Label>
              <Input {...register("referenceNumber")} placeholder="e.g. PO-2024-001 or INV-456" className="bg-background border-input" />
            </div>
            <div className="space-y-1.5">
              <Label>Notes</Label>
              <Input {...register("notes")} placeholder="Additional notes" className="bg-background border-input" />
            </div>

            <DialogFooter>
              <Button type="button" variant="outline" onClick={() => { setDialogOpen(false); reset(); }} className="border-border">Cancel</Button>
              <Button type="submit" disabled={createTx.isPending} className="bg-primary text-primary-foreground hover:bg-primary/90">
                {createTx.isPending ? "Saving..." : "Record Transaction"}
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>
    </div>
  );
}
