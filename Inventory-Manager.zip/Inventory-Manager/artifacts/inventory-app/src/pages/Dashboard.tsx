import {
  useGetDashboardStats,
  useGetStockValueTrend,
  useGetRecentActivity,
  useGetCategoryBreakdown,
  useListProducts,
  getListProductsQueryKey,
} from "@workspace/api-client-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { formatCurrency, formatNumber, formatDate, calcGSTPrice } from "@/lib/formatters";
import {
  AreaChart, Area, XAxis, YAxis, Tooltip, ResponsiveContainer,
  PieChart, Pie, Cell,
} from "recharts";
import { Package, IndianRupee, AlertTriangle, RefreshCw, ShoppingCart, AlertCircle, TrendingUp } from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";
import { Badge } from "@/components/ui/badge";

const CRITICAL_THRESHOLD = 5;

export default function Dashboard() {
  const { data: stats, isLoading: statsLoading } = useGetDashboardStats();
  const { data: trends, isLoading: trendsLoading } = useGetStockValueTrend();
  const { data: activities, isLoading: activitiesLoading } = useGetRecentActivity({ query: { params: { limit: 8 } } });
  const { data: breakdown, isLoading: breakdownLoading } = useGetCategoryBreakdown();
  const { data: allProducts } = useListProducts({ query: { queryKey: getListProductsQueryKey() } });

  const criticalItems = allProducts?.filter(p => p.quantity > 0 && p.quantity <= CRITICAL_THRESHOLD) ?? [];
  const gstTotalValue = allProducts?.reduce((acc, p) => acc + calcGSTPrice(Number(p.unitPrice), Number(p.gstPercent ?? 18)) * p.quantity, 0) ?? 0;

  const PIE_COLORS = ["#3B82F6", "#10B981", "#F59E0B", "#8B5CF6", "#F43F5E"];

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-3xl font-bold tracking-tight">Dashboard</h1>
        <span className="text-xs text-muted-foreground font-mono">{new Date().toLocaleDateString("en-IN", { day: "2-digit", month: "short", year: "numeric" })}</span>
      </div>

      {/* CRITICAL STOCK ALERT BANNER */}
      {criticalItems.length > 0 && (
        <div className="border border-red-500/40 bg-red-500/10 rounded-lg p-4">
          <div className="flex items-start gap-3">
            <AlertTriangle className="w-5 h-5 text-red-400 mt-0.5 shrink-0" />
            <div className="flex-1 min-w-0">
              <p className="text-sm font-semibold text-red-400 mb-2">
                {criticalItems.length} Critical Stock Alert{criticalItems.length > 1 ? "s" : ""} — Immediate Reorder Required
              </p>
              <div className="flex flex-wrap gap-2">
                {criticalItems.map(p => (
                  <span key={p.id} className="inline-flex items-center gap-1.5 bg-red-500/20 border border-red-500/30 text-red-300 text-xs font-mono px-2 py-1 rounded">
                    {p.name}
                    <Badge variant="outline" className="bg-red-600/30 text-red-300 border-red-500/40 text-[10px] px-1.5 py-0 font-bold">
                      {p.quantity} left
                    </Badge>
                  </span>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* STAT CARDS */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4">
        <StatCard title="Total Value" value={stats ? formatCurrency(stats.totalValue) : null} icon={IndianRupee} loading={statsLoading} />
        <StatCard title="GST-Incl. Value" value={allProducts ? formatCurrency(gstTotalValue) : null} icon={TrendingUp} loading={statsLoading} hint="@18% avg GST" />
        <StatCard title="Products" value={stats ? formatNumber(stats.totalProducts) : null} icon={Package} loading={statsLoading} />
        <StatCard title="Total Units" value={stats ? formatNumber(stats.totalItems) : null} icon={ShoppingCart} loading={statsLoading} />
        <StatCard
          title="Low Stock"
          value={stats ? formatNumber(stats.lowStockCount + stats.outOfStockCount) : null}
          icon={AlertCircle}
          loading={statsLoading}
          alert={(stats?.lowStockCount ?? 0) + (stats?.outOfStockCount ?? 0) > 0}
        />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* TREND CHART */}
        <Card className="lg:col-span-2 glass-card">
          <CardHeader>
            <CardTitle className="text-sm font-medium text-muted-foreground uppercase tracking-wider">Inventory Value Trend</CardTitle>
          </CardHeader>
          <CardContent>
            {trendsLoading ? (
              <Skeleton className="h-[280px] w-full" />
            ) : (
              <div className="h-[280px] w-full">
                <ResponsiveContainer width="100%" height="100%">
                  <AreaChart data={trends} margin={{ top: 10, right: 10, left: 0, bottom: 0 }}>
                    <defs>
                      <linearGradient id="colorValue" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="5%" stopColor="#3B82F6" stopOpacity={0.3} />
                        <stop offset="95%" stopColor="#3B82F6" stopOpacity={0} />
                      </linearGradient>
                    </defs>
                    <XAxis dataKey="date" tickFormatter={(v) => v.slice(5)} stroke="#475569" fontSize={11} tickLine={false} axisLine={false} />
                    <YAxis tickFormatter={(v) => `₹${(v / 1000).toFixed(0)}k`} stroke="#475569" fontSize={11} tickLine={false} axisLine={false} />
                    <Tooltip
                      contentStyle={{ backgroundColor: "#0C0F15", borderColor: "#1C2330", borderRadius: "6px" }}
                      itemStyle={{ color: "#F0F4F8" }}
                      formatter={(v: number) => [formatCurrency(v), "Value"]}
                      labelFormatter={(l) => `Date: ${l}`}
                    />
                    <Area type="monotone" dataKey="value" stroke="#3B82F6" strokeWidth={2} fillOpacity={1} fill="url(#colorValue)" />
                  </AreaChart>
                </ResponsiveContainer>
              </div>
            )}
          </CardContent>
        </Card>

        {/* CATEGORY DONUT */}
        <Card className="glass-card">
          <CardHeader>
            <CardTitle className="text-sm font-medium text-muted-foreground uppercase tracking-wider">Category Breakdown</CardTitle>
          </CardHeader>
          <CardContent>
            {breakdownLoading ? (
              <Skeleton className="h-[280px] w-full" />
            ) : (
              <div>
                <div className="h-[220px] w-full">
                  <ResponsiveContainer width="100%" height="100%">
                    <PieChart>
                      <Pie data={breakdown} cx="50%" cy="50%" innerRadius={55} outerRadius={90} paddingAngle={2} dataKey="totalValue" nameKey="categoryName" stroke="none">
                        {breakdown?.map((_, i) => <Cell key={i} fill={PIE_COLORS[i % PIE_COLORS.length]} />)}
                      </Pie>
                      <Tooltip
                        contentStyle={{ backgroundColor: "#0C0F15", borderColor: "#1C2330", borderRadius: "6px" }}
                        formatter={(v: number) => [formatCurrency(v), "Value"]}
                      />
                    </PieChart>
                  </ResponsiveContainer>
                </div>
                <div className="mt-3 flex flex-wrap justify-center gap-x-3 gap-y-1.5">
                  {breakdown?.slice(0, 5).map((e, i) => (
                    <div key={e.categoryName} className="flex items-center gap-1.5 text-xs text-muted-foreground">
                      <div className="w-2 h-2 rounded-full" style={{ backgroundColor: PIE_COLORS[i % PIE_COLORS.length] }} />
                      <span>{e.categoryName}</span>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      {/* RECENT ACTIVITY */}
      <Card className="glass-card">
        <CardHeader>
          <CardTitle className="text-sm font-medium text-muted-foreground uppercase tracking-wider">Recent Activity Log</CardTitle>
        </CardHeader>
        <CardContent>
          {activitiesLoading ? (
            <div className="space-y-3">{[1,2,3,4].map(i => <Skeleton key={i} className="h-14 w-full" />)}</div>
          ) : activities?.length === 0 ? (
            <div className="text-center py-8 text-muted-foreground text-sm">No recent activity recorded</div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              {activities?.map((a) => {
                const isIn = a.type === "stock_in";
                const isOut = a.type === "stock_out";
                return (
                  <div key={a.id} className="flex items-start gap-3 p-3 rounded-md bg-white/5 border border-white/5">
                    <div className={`p-2 rounded-full ${isIn ? "bg-emerald-500/20 text-emerald-400" : isOut ? "bg-red-500/20 text-red-400" : "bg-amber-500/20 text-amber-400"}`}>
                      <RefreshCw className="w-3.5 h-3.5" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center justify-between gap-2">
                        <p className="text-sm font-medium text-foreground truncate">{a.description}</p>
                        {a.quantity && (
                          <span className={`text-xs font-mono font-bold shrink-0 ${isIn ? "text-emerald-400" : isOut ? "text-red-400" : "text-amber-400"}`}>
                            {isIn ? "+" : isOut ? "-" : "±"}{a.quantity}
                          </span>
                        )}
                      </div>
                      <p className="text-xs text-muted-foreground mt-0.5">{formatDate(a.createdAt)}</p>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}

function StatCard({ title, value, icon: Icon, loading, alert = false, hint }: {
  title: string; value: string | null; icon: any; loading: boolean; alert?: boolean; hint?: string;
}) {
  return (
    <Card className={`glass-card ${alert ? "border-red-500/40 shadow-[0_0_15px_rgba(239,68,68,0.08)]" : ""}`}>
      <CardContent className="p-5">
        <div className="flex justify-between items-start">
          <div className="space-y-1.5 min-w-0">
            <p className="text-xs font-medium text-muted-foreground uppercase tracking-wider">{title}</p>
            {loading ? (
              <Skeleton className="h-7 w-24" />
            ) : (
              <p className={`text-xl font-bold tracking-tight ${alert ? "text-red-400" : "text-foreground"}`}>{value}</p>
            )}
            {hint && <p className="text-[10px] text-muted-foreground">{hint}</p>}
          </div>
          <div className={`p-2 rounded-md shrink-0 ${alert ? "bg-red-500/20 text-red-400" : "bg-primary/20 text-primary"}`}>
            <Icon className="w-4 h-4" />
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
