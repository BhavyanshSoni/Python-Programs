import { useState } from "react";
import { useForm } from "react-hook-form";
import { z } from "zod";
import { zodResolver } from "@hookform/resolvers/zod";
import { toast } from "sonner";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Separator } from "@/components/ui/separator";
import { Building2, IndianRupee, AlertTriangle, Info, Save, RotateCcw } from "lucide-react";

const STORAGE_KEY = "stockiq_settings";

export type AppSettings = {
  businessName: string;
  gstin: string;
  address: string;
  phone: string;
  email: string;
  defaultGst: number;
  lowStockThreshold: number;
  criticalStockThreshold: number;
};

export const DEFAULT_SETTINGS: AppSettings = {
  businessName: "",
  gstin: "",
  address: "",
  phone: "",
  email: "",
  defaultGst: 18,
  lowStockThreshold: 10,
  criticalStockThreshold: 5,
};

export function loadSettings(): AppSettings {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (raw) return { ...DEFAULT_SETTINGS, ...JSON.parse(raw) };
  } catch {}
  return { ...DEFAULT_SETTINGS };
}

export function saveSettings(s: AppSettings) {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(s));
}

const schema = z.object({
  businessName: z.string().min(1, "Business name is required"),
  gstin: z.string().optional(),
  address: z.string().optional(),
  phone: z.string().optional(),
  email: z.string().email("Invalid email").optional().or(z.literal("")),
  defaultGst: z.coerce.number().min(0).max(100),
  lowStockThreshold: z.coerce.number().int().min(1),
  criticalStockThreshold: z.coerce.number().int().min(1),
});
type SettingsForm = z.infer<typeof schema>;

export default function Settings() {
  const [saved, setSaved] = useState(false);
  const stored = loadSettings();

  const { register, handleSubmit, reset, formState: { errors, isDirty } } = useForm<SettingsForm>({
    resolver: zodResolver(schema),
    defaultValues: stored,
  });

  const onSubmit = (data: SettingsForm) => {
    saveSettings(data as AppSettings);
    setSaved(true);
    reset(data);
    toast.success("Settings saved successfully");
    setTimeout(() => setSaved(false), 2000);
  };

  const handleReset = () => {
    reset(DEFAULT_SETTINGS);
    saveSettings(DEFAULT_SETTINGS);
    toast.info("Settings reset to defaults");
  };

  return (
    <div className="space-y-6 max-w-2xl">
      <div className="flex justify-between items-center">
        <h1 className="text-3xl font-bold tracking-tight">Settings</h1>
      </div>

      <form onSubmit={handleSubmit(onSubmit)} className="space-y-6">
        {/* BUSINESS INFO */}
        <Card className="glass-card">
          <CardHeader className="pb-3">
            <div className="flex items-center gap-2">
              <Building2 className="w-4 h-4 text-primary" />
              <CardTitle className="text-base">Business Information</CardTitle>
            </div>
            <CardDescription className="text-xs">Appears on exported reports and documents</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-1.5">
              <Label>Business / Company Name <span className="text-destructive">*</span></Label>
              <Input {...register("businessName")} placeholder="e.g. Sharma Enterprises Pvt Ltd" className="bg-background border-input" />
              {errors.businessName && <p className="text-xs text-destructive">{errors.businessName.message}</p>}
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-1.5">
                <Label>GSTIN</Label>
                <Input {...register("gstin")} placeholder="e.g. 22AAAAA0000A1Z5" className="bg-background border-input font-mono" maxLength={15} />
              </div>
              <div className="space-y-1.5">
                <Label>Phone</Label>
                <Input {...register("phone")} placeholder="+91-XXXXX-XXXXX" className="bg-background border-input" />
              </div>
            </div>
            <div className="space-y-1.5">
              <Label>Business Address</Label>
              <Input {...register("address")} placeholder="Full address with city, state and PIN" className="bg-background border-input" />
            </div>
            <div className="space-y-1.5">
              <Label>Business Email</Label>
              <Input {...register("email")} type="email" placeholder="accounts@yourbusiness.com" className="bg-background border-input" />
              {errors.email && <p className="text-xs text-destructive">{errors.email.message}</p>}
            </div>
          </CardContent>
        </Card>

        {/* TAX & INVENTORY */}
        <Card className="glass-card">
          <CardHeader className="pb-3">
            <div className="flex items-center gap-2">
              <IndianRupee className="w-4 h-4 text-emerald-400" />
              <CardTitle className="text-base">Tax & Inventory Defaults</CardTitle>
            </div>
            <CardDescription className="text-xs">Used as defaults when adding new products</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-1.5">
              <Label>Default GST Rate (%)</Label>
              <Input {...register("defaultGst")} type="number" min="0" max="100" step="0.1" className="bg-background border-input w-32" />
              {errors.defaultGst && <p className="text-xs text-destructive">{errors.defaultGst.message}</p>}
              <p className="text-xs text-muted-foreground">Common rates: 0% · 5% · 12% · 18% · 28%</p>
            </div>
          </CardContent>
        </Card>

        {/* STOCK ALERTS */}
        <Card className="glass-card">
          <CardHeader className="pb-3">
            <div className="flex items-center gap-2">
              <AlertTriangle className="w-4 h-4 text-amber-400" />
              <CardTitle className="text-base">Stock Alert Thresholds</CardTitle>
            </div>
            <CardDescription className="text-xs">Quantities that trigger alerts on the dashboard and products page</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-2 gap-6">
              <div className="space-y-1.5">
                <Label>Low Stock Warning (units)</Label>
                <Input {...register("lowStockThreshold")} type="number" min="1" step="1" className="bg-background border-input" />
                {errors.lowStockThreshold && <p className="text-xs text-destructive">{errors.lowStockThreshold.message}</p>}
                <p className="text-xs text-muted-foreground">Products at or below this qty show as "Low Stock"</p>
              </div>
              <div className="space-y-1.5">
                <Label>Critical Stock Alert (units)</Label>
                <Input {...register("criticalStockThreshold")} type="number" min="1" step="1" className="bg-background border-input" />
                {errors.criticalStockThreshold && <p className="text-xs text-destructive">{errors.criticalStockThreshold.message}</p>}
                <p className="text-xs text-muted-foreground">Products at or below this qty trigger the red alert banner</p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* APP INFO */}
        <Card className="glass-card border-border/40">
          <CardHeader className="pb-3">
            <div className="flex items-center gap-2">
              <Info className="w-4 h-4 text-muted-foreground" />
              <CardTitle className="text-base text-muted-foreground">About StockIQ</CardTitle>
            </div>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 gap-3 text-sm">
              <div className="flex justify-between">
                <span className="text-muted-foreground">Version</span>
                <span className="font-mono text-xs">1.0.0</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Currency</span>
                <span className="font-mono text-xs">INR (₹)</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Date Format</span>
                <span className="font-mono text-xs">DD-MM-YYYY</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Locale</span>
                <span className="font-mono text-xs">en-IN</span>
              </div>
            </div>
          </CardContent>
        </Card>

        <Separator className="bg-border/40" />

        <div className="flex items-center gap-3">
          <Button type="submit" className="bg-primary text-primary-foreground hover:bg-primary/90 gap-2">
            <Save className="w-4 h-4" />
            {saved ? "Saved!" : isDirty ? "Save Changes" : "Save Settings"}
          </Button>
          <Button type="button" variant="outline" onClick={handleReset} className="border-border text-muted-foreground gap-2">
            <RotateCcw className="w-4 h-4" />
            Reset to Defaults
          </Button>
        </div>
      </form>
    </div>
  );
}
