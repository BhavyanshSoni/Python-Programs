import { useGetLowStockReport, useGetInventoryValueReport, useGetTopProducts } from "@workspace/api-client-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Skeleton } from "@/components/ui/skeleton";
import { formatCurrency, formatNumber, calcGSTPrice, exportToCSV, formatDate } from "@/lib/formatters";
import { StatusBadge } from "@/components/shared/StatusBadge";
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid } from "recharts";
import { Download, AlertTriangle, TrendingUp, Award } from "lucide-react";
import { toast } from "sonner";

const CRITICAL_QTY = 5;

export default function Reports() {
  const { data: lowStockItems, isLoading: lowStockLoading } = useGetLowStockReport();
  const { data: valueReport, isLoading: valueLoading } = useGetInventoryValueReport();
  const { data: topProducts, isLoading: topLoading } = useGetTopProducts({ query: { params: { limit: 10 } } });

  const handleExportLowStock = () => {
    if (!lowStockItems?.length) { toast.error("No data to export"); return; }
    exportToCSV("stockiq-low-stock-report.csv", lowStockItems.map(p => ({
      SKU: p.sku, Name: p.name, Category: p.categoryName ?? "",
      Quantity: p.quantity, "Min Stock": p.minStockLevel,
      "Unit Price (₹)": Number(p.unitPrice).toFixed(2),
      "GST (%)": Number(p.gstPercent ?? 18),
      "GST-Incl. Price (₹)": calcGSTPrice(Number(p.unitPrice), Number(p.gstPercent ?? 18)).toFixed(2),
      Location: p.location ?? "", Supplier: p.supplierName ?? "",
      Status: p.quantity === 0 ? "Out of Stock" : p.quantity <= CRITICAL_QTY ? "Critical" : "Low Stock",
    })));
    toast.success("Low stock report exported");
  };

  const handleExportTopProducts = () => {
    if (!topProducts?.length) { toast.error("No data to export"); return; }
    exportToCSV("stockiq-top-products.csv", topProducts.map(p => ({
      SKU: p.sku, Product: p.productName,
      Transactions: p.totalTransactions, "Total Qty Sold": p.totalQuantity,
      "Total Revenue (₹)": Number(p.totalRevenue).toFixed(2),
    })));
    toast.success("Top products report exported");
  };

  const handleExportValueReport = () => {
    if (!valueReport?.length) { toast.error("No data to export"); return; }
    exportToCSV("stockiq-inventory-value.csv", valueReport.map(r => ({
      Category: r.categoryName, Products: r.productCount,
      "Total Value (₹)": Number(r.totalValue).toFixed(2),
      "Share (%)": r.percentage,
    })));
    toast.success("Inventory value report exported");
  };

  const criticalCount = lowStockItems?.filter(p => p.quantity > 0 && p.quantity <= CRITICAL_QTY).length ?? 0;
  const outOfStockCount = lowStockItems?.filter(p => p.quantity === 0).length ?? 0;

  return (
    <div className="space-y-8">
      <div className="flex justify-between items-center">
        <h1 className="text-3xl font-bold tracking-tight">Reports & Analytics</h1>
        <p className="text-xs text-muted-foreground font-mono">Generated: {new Date().toLocaleDateString("en-IN", { day: "2-digit", month: "short", year: "numeric", hour: "2-digit", minute: "2-digit" })}</p>
      </div>

      {/* LOW STOCK REPORT */}
      <section className="space-y-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <AlertTriangle className="w-4 h-4 text-amber-400" />
            <h2 className="text-lg font-semibold">Low Stock Report</h2>
            {!lowStockLoading && (
              <div className="flex gap-1.5">
                {criticalCount > 0 && <span className="text-xs bg-red-500/20 text-red-400 border border-red-500/30 px-2 py-0.5 rounded font-mono">{criticalCount} critical</span>}
                {outOfStockCount > 0 && <span className="text-xs bg-red-900/30 text-red-500 border border-red-700/30 px-2 py-0.5 rounded font-mono">{outOfStockCount} out of stock</span>}
              </div>
            )}
          </div>
          <Button variant="outline" size="sm" onClick={handleExportLowStock} className="border-border text-muted-foreground hover:text-foreground">
            <Download className="w-4 h-4 mr-1.5" /> Export CSV
          </Button>
        </div>
        <Card className="glass-card overflow-hidden">
          <div className="overflow-x-auto">
            <Table>
              <TableHeader className="bg-muted/50">
                <TableRow className="border-border">
                  <TableHead>SKU</TableHead>
                  <TableHead>Product</TableHead>
                  <TableHead>Category</TableHead>
                  <TableHead>Supplier</TableHead>
                  <TableHead className="text-right">Qty</TableHead>
                  <TableHead className="text-right">Min Stock</TableHead>
                  <TableHead className="text-right">Unit Price</TableHead>
                  <TableHead>Status</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {lowStockLoading ? (
                  Array.from({ length: 4 }).map((_, i) => (
                    <TableRow key={i} className="border-border">
                      {Array.from({ length: 8 }).map((_, j) => <TableCell key={j}><Skeleton className="h-4 w-full" /></TableCell>)}
                    </TableRow>
                  ))
                ) : lowStockItems?.length === 0 ? (
                  <TableRow><TableCell colSpan={8} className="text-center py-12 text-emerald-400">All stock levels are healthy</TableCell></TableRow>
                ) : (
                  lowStockItems?.map(p => {
                    const isCritical = p.quantity > 0 && p.quantity <= CRITICAL_QTY;
                    const isOut = p.quantity === 0;
                    return (
                      <TableRow key={p.id} className={`border-border transition-colors ${isOut ? "bg-red-950/20" : isCritical ? "bg-red-500/5" : ""}`}>
                        <TableCell className="font-mono text-xs text-muted-foreground">{p.sku}</TableCell>
                        <TableCell className="font-medium text-sm">{p.name}</TableCell>
                        <TableCell><span className="text-xs bg-secondary/60 px-2 py-0.5 rounded">{p.categoryName || "—"}</span></TableCell>
                        <TableCell className="text-sm text-muted-foreground">{p.supplierName || "—"}</TableCell>
                        <TableCell className={`text-right font-mono font-bold ${isCritical || isOut ? "text-red-400" : "text-amber-400"}`}>{p.quantity}</TableCell>
                        <TableCell className="text-right font-mono text-muted-foreground">{p.minStockLevel}</TableCell>
                        <TableCell className="text-right font-mono text-sm">{formatCurrency(Number(p.unitPrice))}</TableCell>
                        <TableCell>
                          {isOut ? <StatusBadge type="out_of_stock" />
                            : isCritical ? <StatusBadge type="out_of_stock" label="Critical" />
                            : <StatusBadge type="low_stock" />}
                        </TableCell>
                      </TableRow>
                    );
                  })
                )}
              </TableBody>
            </Table>
          </div>
        </Card>
      </section>

      {/* INVENTORY VALUE BY CATEGORY */}
      <section className="space-y-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <TrendingUp className="w-4 h-4 text-primary" />
            <h2 className="text-lg font-semibold">Inventory Value by Category</h2>
          </div>
          <Button variant="outline" size="sm" onClick={handleExportValueReport} className="border-border text-muted-foreground hover:text-foreground">
            <Download className="w-4 h-4 mr-1.5" /> Export CSV
          </Button>
        </div>
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
          <Card className="lg:col-span-2 glass-card">
            <CardContent className="pt-4">
              {valueLoading ? <Skeleton className="h-[280px] w-full" /> : (
                <div className="h-[280px]">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={valueReport} margin={{ top: 4, right: 4, left: 0, bottom: 0 }}>
                      <CartesianGrid strokeDasharray="3 3" stroke="#1C2330" vertical={false} />
                      <XAxis dataKey="categoryName" stroke="#475569" fontSize={11} tickLine={false} axisLine={false} />
                      <YAxis tickFormatter={v => `₹${(v / 1000).toFixed(0)}k`} stroke="#475569" fontSize={11} tickLine={false} axisLine={false} />
                      <Tooltip
                        contentStyle={{ backgroundColor: "#0C0F15", borderColor: "#1C2330", borderRadius: "6px" }}
                        formatter={(v: number) => [formatCurrency(v), "Value"]}
                      />
                      <Bar dataKey="totalValue" fill="#3B82F6" radius={[4, 4, 0, 0]} />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              )}
            </CardContent>
          </Card>
          <Card className="glass-card">
            <CardHeader><CardTitle className="text-xs text-muted-foreground uppercase tracking-wider">Breakdown</CardTitle></CardHeader>
            <CardContent>
              {valueLoading ? (
                <div className="space-y-3">{[1,2,3,4].map(i => <Skeleton key={i} className="h-8 w-full" />)}</div>
              ) : (
                <div className="space-y-3">
                  {valueReport?.map((r, i) => (
                    <div key={r.categoryName} className="flex items-center gap-2">
                      <div className="w-2 h-2 rounded-full shrink-0" style={{ backgroundColor: ["#3B82F6","#10B981","#F59E0B","#8B5CF6","#F43F5E"][i % 5] }} />
                      <div className="flex-1 min-w-0">
                        <div className="flex justify-between items-center">
                          <span className="text-xs font-medium truncate">{r.categoryName}</span>
                          <span className="text-xs text-muted-foreground ml-1">{r.percentage}%</span>
                        </div>
                        <div className="mt-1 h-1 bg-muted rounded-full overflow-hidden">
                          <div className="h-full rounded-full" style={{ width: `${r.percentage}%`, backgroundColor: ["#3B82F6","#10B981","#F59E0B","#8B5CF6","#F43F5E"][i % 5] }} />
                        </div>
                        <span className="text-xs text-muted-foreground">{formatCurrency(Number(r.totalValue))}</span>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </section>

      {/* TOP PRODUCTS */}
      <section className="space-y-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Award className="w-4 h-4 text-amber-400" />
            <h2 className="text-lg font-semibold">Top Products by Revenue</h2>
          </div>
          <Button variant="outline" size="sm" onClick={handleExportTopProducts} className="border-border text-muted-foreground hover:text-foreground">
            <Download className="w-4 h-4 mr-1.5" /> Export CSV
          </Button>
        </div>
        <Card className="glass-card overflow-hidden">
          <div className="overflow-x-auto">
            <Table>
              <TableHeader className="bg-muted/50">
                <TableRow className="border-border">
                  <TableHead className="w-10">#</TableHead>
                  <TableHead>Product</TableHead>
                  <TableHead className="text-right">Transactions</TableHead>
                  <TableHead className="text-right">Total Qty</TableHead>
                  <TableHead className="text-right">Total Revenue</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {topLoading ? (
                  Array.from({ length: 5 }).map((_, i) => (
                    <TableRow key={i} className="border-border">
                      {Array.from({ length: 5 }).map((_, j) => <TableCell key={j}><Skeleton className="h-4 w-full" /></TableCell>)}
                    </TableRow>
                  ))
                ) : topProducts?.length === 0 ? (
                  <TableRow><TableCell colSpan={5} className="text-center py-12 text-muted-foreground">No transactions yet</TableCell></TableRow>
                ) : (
                  topProducts?.map((p, i) => (
                    <TableRow key={p.productId} className="border-border hover:bg-white/5 transition-colors">
                      <TableCell className={`text-center font-bold text-sm ${i === 0 ? "text-amber-400" : i === 1 ? "text-slate-300" : i === 2 ? "text-amber-700" : "text-muted-foreground"}`}>
                        {i + 1}
                      </TableCell>
                      <TableCell>
                        <p className="font-medium text-sm">{p.productName}</p>
                        <p className="text-xs text-muted-foreground font-mono">{p.sku}</p>
                      </TableCell>
                      <TableCell className="text-right font-mono text-sm">{formatNumber(p.totalTransactions)}</TableCell>
                      <TableCell className="text-right font-mono text-sm">{formatNumber(p.totalQuantity)}</TableCell>
                      <TableCell className="text-right font-mono font-semibold text-sm text-emerald-400">{formatCurrency(Number(p.totalRevenue))}</TableCell>
                    </TableRow>
                  ))
                )}
              </TableBody>
            </Table>
          </div>
        </Card>
      </section>
    </div>
  );
}
