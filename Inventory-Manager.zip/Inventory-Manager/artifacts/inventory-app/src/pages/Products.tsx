import { useState, useMemo } from "react";
import { useForm } from "react-hook-form";
import { z } from "zod";
import { zodResolver } from "@hookform/resolvers/zod";
import {
  useListProducts, useListCategories, useListSuppliers,
  useDeleteProduct, useCreateProduct, useUpdateProduct,
  getListProductsQueryKey,
} from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { formatCurrency, formatNumber, calcGSTPrice, exportToCSV, formatDate } from "@/lib/formatters";
import { StatusBadge } from "@/components/shared/StatusBadge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from "@/components/ui/alert-dialog";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Card } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { Search, Plus, Edit2, Trash2, Download, AlertTriangle, IndianRupee } from "lucide-react";

const CRITICAL_QTY = 5;

const productSchema = z.object({
  name: z.string().min(1, "Product name is required"),
  sku: z.string().min(1, "SKU is required"),
  description: z.string().optional(),
  categoryId: z.union([z.coerce.number().int().positive(), z.literal(0)]).optional().transform(v => v === 0 ? undefined : v),
  supplierId: z.union([z.coerce.number().int().positive(), z.literal(0)]).optional().transform(v => v === 0 ? undefined : v),
  quantity: z.coerce.number().int("Must be a whole number").min(0, "Quantity must be 0 or more"),
  minStockLevel: z.coerce.number().int("Must be a whole number").min(1, "Min stock level must be at least 1"),
  unitPrice: z.coerce.number().positive("Price must be greater than ₹0"),
  gstPercent: z.coerce.number().min(0, "GST cannot be negative").max(100, "GST cannot exceed 100%"),
  barcode: z.string().optional(),
  location: z.string().optional(),
});
type ProductForm = z.infer<typeof productSchema>;

type StockFilter = "all" | "in_stock" | "low_stock" | "critical" | "out_of_stock";

export default function Products() {
  const queryClient = useQueryClient();
  const [search, setSearch] = useState("");
  const [categoryId, setCategoryId] = useState<string>("all");
  const [stockFilter, setStockFilter] = useState<StockFilter>("all");
  const [addOpen, setAddOpen] = useState(false);
  const [editProduct, setEditProduct] = useState<any | null>(null);
  const [deleteId, setDeleteId] = useState<number | null>(null);

  const { data: products, isLoading } = useListProducts({
    query: {
      queryKey: getListProductsQueryKey({ search: search || undefined }),
      params: { search: search || undefined },
    },
  });
  const { data: categories } = useListCategories();
  const { data: suppliers } = useListSuppliers({ query: { params: {} } });
  const deleteProduct = useDeleteProduct();
  const createProduct = useCreateProduct();
  const updateProduct = useUpdateProduct();

  const filtered = useMemo(() => {
    let list = products ?? [];
    if (categoryId !== "all") list = list.filter(p => p.categoryId === Number(categoryId));
    switch (stockFilter) {
      case "in_stock": list = list.filter(p => p.quantity > p.minStockLevel); break;
      case "low_stock": list = list.filter(p => p.quantity > CRITICAL_QTY && p.quantity <= p.minStockLevel); break;
      case "critical": list = list.filter(p => p.quantity > 0 && p.quantity <= CRITICAL_QTY); break;
      case "out_of_stock": list = list.filter(p => p.quantity === 0); break;
    }
    return list;
  }, [products, categoryId, stockFilter]);

  const criticalItems = useMemo(() => (products ?? []).filter(p => p.quantity > 0 && p.quantity <= CRITICAL_QTY), [products]);

  const handleExportCSV = () => {
    if (!filtered.length) { toast.error("No products to export"); return; }
    const rows = filtered.map(p => ({
      SKU: p.sku,
      Name: p.name,
      Category: p.categoryName ?? "",
      Supplier: p.supplierName ?? "",
      Qty: p.quantity,
      "Min Stock": p.minStockLevel,
      "Unit Price (₹)": Number(p.unitPrice).toFixed(2),
      "GST (%)": Number(p.gstPercent ?? 18),
      "GST-Incl. Price (₹)": calcGSTPrice(Number(p.unitPrice), Number(p.gstPercent ?? 18)).toFixed(2),
      "Total Value (₹)": (Number(p.unitPrice) * p.quantity).toFixed(2),
      Location: p.location ?? "",
      Barcode: p.barcode ?? "",
      Status: p.quantity === 0 ? "Out of Stock" : p.quantity <= CRITICAL_QTY ? "Critical" : p.quantity <= p.minStockLevel ? "Low Stock" : "In Stock",
      "Added On": p.createdAt ? new Date(p.createdAt).toLocaleDateString("en-IN") : "",
    }));
    exportToCSV(`stockiq-products-${new Date().toLocaleDateString("en-IN").replace(/\//g, "-")}.csv`, rows);
    toast.success(`Exported ${rows.length} products`);
  };

  const handleDelete = () => {
    if (deleteId == null) return;
    deleteProduct.mutate({ id: deleteId }, {
      onSuccess: () => { toast.success("Product deleted"); queryClient.invalidateQueries({ queryKey: getListProductsQueryKey() }); setDeleteId(null); },
      onError: () => toast.error("Failed to delete product"),
    });
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-3xl font-bold tracking-tight">Products</h1>
        <div className="flex items-center gap-2">
          <Button variant="outline" size="sm" onClick={handleExportCSV} className="border-border text-muted-foreground hover:text-foreground">
            <Download className="w-4 h-4 mr-1.5" /> Export CSV
          </Button>
          <Button size="sm" className="bg-primary text-primary-foreground hover:bg-primary/90" onClick={() => setAddOpen(true)}>
            <Plus className="w-4 h-4 mr-1.5" /> Add Product
          </Button>
        </div>
      </div>

      {/* CRITICAL STOCK BANNER */}
      {criticalItems.length > 0 && (
        <div className="border border-red-500/40 bg-red-500/8 rounded-lg px-4 py-3 flex items-start gap-3">
          <AlertTriangle className="w-4 h-4 text-red-400 mt-0.5 shrink-0" />
          <div>
            <span className="text-sm font-semibold text-red-400 mr-2">
              {criticalItems.length} item{criticalItems.length > 1 ? "s" : ""} critically low (≤{CRITICAL_QTY} units):
            </span>
            <span className="text-sm text-red-300/80">{criticalItems.map(p => `${p.name} (${p.quantity})`).join(", ")}</span>
          </div>
        </div>
      )}

      {/* FILTERS */}
      <div className="flex items-center gap-3 bg-card p-3 rounded-lg border border-border flex-wrap">
        <div className="relative flex-1 min-w-[200px]">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input placeholder="Search by name, SKU, or barcode..." className="pl-9 bg-background border-input h-9" value={search} onChange={e => setSearch(e.target.value)} />
        </div>
        <div className="w-[160px]">
          <Select value={categoryId} onValueChange={setCategoryId}>
            <SelectTrigger className="bg-background border-input h-9"><SelectValue placeholder="All Categories" /></SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Categories</SelectItem>
              {categories?.map(c => <SelectItem key={c.id} value={String(c.id)}>{c.name}</SelectItem>)}
            </SelectContent>
          </Select>
        </div>
        <div className="w-[160px]">
          <Select value={stockFilter} onValueChange={v => setStockFilter(v as StockFilter)}>
            <SelectTrigger className="bg-background border-input h-9"><SelectValue placeholder="Stock Status" /></SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Status</SelectItem>
              <SelectItem value="in_stock">In Stock</SelectItem>
              <SelectItem value="low_stock">Low Stock</SelectItem>
              <SelectItem value="critical">Critical (≤{CRITICAL_QTY})</SelectItem>
              <SelectItem value="out_of_stock">Out of Stock</SelectItem>
            </SelectContent>
          </Select>
        </div>
        <span className="text-xs text-muted-foreground ml-auto">{filtered.length} product{filtered.length !== 1 ? "s" : ""}</span>
      </div>

      {/* TABLE */}
      <Card className="glass-card overflow-hidden">
        <div className="overflow-x-auto">
          <Table>
            <TableHeader className="bg-muted/50">
              <TableRow className="border-border">
                <TableHead className="w-[100px]">SKU</TableHead>
                <TableHead>Product</TableHead>
                <TableHead>Category</TableHead>
                <TableHead className="text-right">Base Price</TableHead>
                <TableHead className="text-right">GST-Incl.</TableHead>
                <TableHead className="text-right">Stock</TableHead>
                <TableHead>Status</TableHead>
                <TableHead className="text-right">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {isLoading ? (
                Array.from({ length: 6 }).map((_, i) => (
                  <TableRow key={i} className="border-border">
                    {Array.from({ length: 8 }).map((_, j) => <TableCell key={j}><Skeleton className="h-4 w-full" /></TableCell>)}
                  </TableRow>
                ))
              ) : filtered.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={8} className="text-center py-12 text-muted-foreground">No products match your filters</TableCell>
                </TableRow>
              ) : (
                filtered.map(p => {
                  const isCritical = p.quantity > 0 && p.quantity <= CRITICAL_QTY;
                  const isOut = p.quantity === 0;
                  const gstPrice = calcGSTPrice(Number(p.unitPrice), Number(p.gstPercent ?? 18));
                  return (
                    <TableRow key={p.id} className={`border-border transition-colors ${isCritical ? "bg-red-500/5 hover:bg-red-500/10" : isOut ? "bg-red-950/20 hover:bg-red-950/30" : "hover:bg-white/5"}`}>
                      <TableCell className="font-mono text-xs text-muted-foreground">{p.sku}</TableCell>
                      <TableCell>
                        <div>
                          <p className="font-medium text-sm">{p.name}</p>
                          {p.location && <p className="text-xs text-muted-foreground">{p.location}</p>}
                        </div>
                      </TableCell>
                      <TableCell>
                        <span className="bg-secondary/60 text-secondary-foreground px-2 py-0.5 rounded text-xs">{p.categoryName || "—"}</span>
                      </TableCell>
                      <TableCell className="text-right font-mono text-sm">{formatCurrency(Number(p.unitPrice))}</TableCell>
                      <TableCell className="text-right font-mono text-sm text-emerald-400/80">
                        {formatCurrency(gstPrice)}
                        <span className="text-[10px] text-muted-foreground ml-1">+{Number(p.gstPercent ?? 18)}%</span>
                      </TableCell>
                      <TableCell className={`text-right font-mono font-semibold text-sm ${isCritical ? "text-red-400" : isOut ? "text-red-500" : ""}`}>
                        {formatNumber(p.quantity)}
                      </TableCell>
                      <TableCell>
                        {isOut ? <StatusBadge type="out_of_stock" />
                          : isCritical ? <StatusBadge type="out_of_stock" label="Critical" />
                          : p.quantity <= p.minStockLevel ? <StatusBadge type="low_stock" />
                          : <StatusBadge type="in_stock" />}
                      </TableCell>
                      <TableCell className="text-right">
                        <Button variant="ghost" size="icon" className="h-7 w-7 text-muted-foreground hover:text-primary" onClick={() => setEditProduct(p)}>
                          <Edit2 className="h-3.5 w-3.5" />
                        </Button>
                        <Button variant="ghost" size="icon" className="h-7 w-7 text-muted-foreground hover:text-destructive" onClick={() => setDeleteId(p.id)}>
                          <Trash2 className="h-3.5 w-3.5" />
                        </Button>
                      </TableCell>
                    </TableRow>
                  );
                })
              )}
            </TableBody>
          </Table>
        </div>
      </Card>

      {/* ADD DIALOG */}
      <ProductFormDialog
        open={addOpen}
        onClose={() => setAddOpen(false)}
        categories={categories ?? []}
        suppliers={suppliers ?? []}
        onSubmit={(data) => {
          createProduct.mutate({ data: data as any }, {
            onSuccess: () => {
              toast.success("Product added successfully");
              queryClient.invalidateQueries({ queryKey: getListProductsQueryKey() });
              setAddOpen(false);
            },
            onError: (e: any) => toast.error(e?.message ?? "Failed to create product"),
          });
        }}
        isSubmitting={createProduct.isPending}
      />

      {/* EDIT DIALOG */}
      <ProductFormDialog
        open={!!editProduct}
        onClose={() => setEditProduct(null)}
        categories={categories ?? []}
        suppliers={suppliers ?? []}
        defaultValues={editProduct ? {
          name: editProduct.name, sku: editProduct.sku,
          description: editProduct.description ?? "",
          categoryId: editProduct.categoryId ?? 0,
          supplierId: editProduct.supplierId ?? 0,
          quantity: editProduct.quantity, minStockLevel: editProduct.minStockLevel,
          unitPrice: Number(editProduct.unitPrice),
          gstPercent: Number(editProduct.gstPercent ?? 18),
          barcode: editProduct.barcode ?? "", location: editProduct.location ?? "",
        } : undefined}
        onSubmit={(data) => {
          updateProduct.mutate({ id: editProduct.id, data: data as any }, {
            onSuccess: () => {
              toast.success("Product updated");
              queryClient.invalidateQueries({ queryKey: getListProductsQueryKey() });
              setEditProduct(null);
            },
            onError: (e: any) => toast.error(e?.message ?? "Failed to update product"),
          });
        }}
        isSubmitting={updateProduct.isPending}
        isEdit
      />

      {/* DELETE CONFIRM */}
      <AlertDialog open={deleteId !== null} onOpenChange={open => !open && setDeleteId(null)}>
        <AlertDialogContent className="bg-card border-border">
          <AlertDialogHeader>
            <AlertDialogTitle>Delete Product</AlertDialogTitle>
            <AlertDialogDescription>This will permanently delete the product and all its inventory movements. This action cannot be undone.</AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel className="border-border">Cancel</AlertDialogCancel>
            <AlertDialogAction className="bg-destructive text-destructive-foreground hover:bg-destructive/90" onClick={handleDelete}>Delete</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}

function ProductFormDialog({ open, onClose, categories, suppliers, defaultValues, onSubmit, isSubmitting, isEdit = false }: {
  open: boolean; onClose: () => void; categories: any[]; suppliers: any[];
  defaultValues?: Partial<ProductForm>; onSubmit: (data: ProductForm) => void;
  isSubmitting: boolean; isEdit?: boolean;
}) {
  const { register, handleSubmit, watch, reset, setValue, formState: { errors } } = useForm<ProductForm>({
    resolver: zodResolver(productSchema),
    defaultValues: defaultValues ?? { quantity: 0, minStockLevel: 10, unitPrice: 0, gstPercent: 18 },
    values: defaultValues,
  });

  const unitPrice = watch("unitPrice") ?? 0;
  const gstPct = watch("gstPercent") ?? 18;
  const gstPrice = calcGSTPrice(Number(unitPrice) || 0, Number(gstPct) || 0);

  const onFormSubmit = (data: ProductForm) => { onSubmit(data); reset(); };

  return (
    <Dialog open={open} onOpenChange={o => { if (!o) { onClose(); reset(); } }}>
      <DialogContent className="bg-card border-border max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>{isEdit ? "Edit Product" : "Add New Product"}</DialogTitle>
        </DialogHeader>
        <form onSubmit={handleSubmit(onFormSubmit)} className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-1.5">
              <Label htmlFor="name">Product Name <span className="text-destructive">*</span></Label>
              <Input id="name" {...register("name")} placeholder="e.g. Office Chair" className="bg-background border-input" />
              {errors.name && <p className="text-xs text-destructive">{errors.name.message}</p>}
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="sku">SKU <span className="text-destructive">*</span></Label>
              <Input id="sku" {...register("sku")} placeholder="e.g. FURN-001" className="bg-background border-input" />
              {errors.sku && <p className="text-xs text-destructive">{errors.sku.message}</p>}
            </div>
          </div>

          <div className="space-y-1.5">
            <Label htmlFor="description">Description</Label>
            <Input id="description" {...register("description")} placeholder="Product description" className="bg-background border-input" />
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-1.5">
              <Label>Category</Label>
              <Select defaultValue={String(defaultValues?.categoryId ?? 0)} onValueChange={v => setValue("categoryId", Number(v) as any)}>
                <SelectTrigger className="bg-background border-input"><SelectValue placeholder="Select category" /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="0">No Category</SelectItem>
                  {categories.map(c => <SelectItem key={c.id} value={String(c.id)}>{c.name}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-1.5">
              <Label>Supplier</Label>
              <Select defaultValue={String(defaultValues?.supplierId ?? 0)} onValueChange={v => setValue("supplierId", Number(v) as any)}>
                <SelectTrigger className="bg-background border-input"><SelectValue placeholder="Select supplier" /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="0">No Supplier</SelectItem>
                  {suppliers.map(s => <SelectItem key={s.id} value={String(s.id)}>{s.name}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="grid grid-cols-3 gap-4">
            <div className="space-y-1.5">
              <Label htmlFor="quantity">Quantity <span className="text-destructive">*</span></Label>
              <Input id="quantity" type="number" min="0" step="1" {...register("quantity")} className="bg-background border-input" />
              {errors.quantity && <p className="text-xs text-destructive">{errors.quantity.message}</p>}
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="minStockLevel">Min Stock Level <span className="text-destructive">*</span></Label>
              <Input id="minStockLevel" type="number" min="1" step="1" {...register("minStockLevel")} className="bg-background border-input" />
              {errors.minStockLevel && <p className="text-xs text-destructive">{errors.minStockLevel.message}</p>}
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="unitPrice">Unit Price (₹) <span className="text-destructive">*</span></Label>
              <div className="relative">
                <IndianRupee className="absolute left-2.5 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-muted-foreground" />
                <Input id="unitPrice" type="number" min="0.01" step="0.01" {...register("unitPrice")} className="bg-background border-input pl-7" />
              </div>
              {errors.unitPrice && <p className="text-xs text-destructive">{errors.unitPrice.message}</p>}
            </div>
          </div>

          {/* GST FIELD */}
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-1.5">
              <Label htmlFor="gstPercent">GST (%)</Label>
              <Input id="gstPercent" type="number" min="0" max="100" step="0.1" {...register("gstPercent")} className="bg-background border-input" />
              {errors.gstPercent && <p className="text-xs text-destructive">{errors.gstPercent.message}</p>}
            </div>
            <div className="space-y-1.5">
              <Label>GST-Inclusive Price</Label>
              <div className="h-9 flex items-center px-3 rounded-md bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 font-mono text-sm">
                {formatCurrency(gstPrice)}
              </div>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-1.5">
              <Label htmlFor="barcode">Barcode</Label>
              <Input id="barcode" {...register("barcode")} placeholder="Barcode / QR code" className="bg-background border-input" />
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="location">Location</Label>
              <Input id="location" {...register("location")} placeholder="e.g. Shelf A1-S2" className="bg-background border-input" />
            </div>
          </div>

          <DialogFooter className="pt-2">
            <Button type="button" variant="outline" onClick={() => { onClose(); reset(); }} className="border-border">Cancel</Button>
            <Button type="submit" disabled={isSubmitting} className="bg-primary text-primary-foreground hover:bg-primary/90">
              {isSubmitting ? "Saving..." : isEdit ? "Save Changes" : "Add Product"}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}
