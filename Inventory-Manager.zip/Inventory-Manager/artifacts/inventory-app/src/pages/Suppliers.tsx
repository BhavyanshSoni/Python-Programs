import { useState } from "react";
import { useForm } from "react-hook-form";
import { z } from "zod";
import { zodResolver } from "@hookform/resolvers/zod";
import {
  useListSuppliers, useCreateSupplier, useUpdateSupplier, useDeleteSupplier,
  getListSuppliersQueryKey,
} from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { formatDate } from "@/lib/formatters";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from "@/components/ui/alert-dialog";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Card } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { Plus, Search, Edit2, Trash2, Phone, Mail, MapPin } from "lucide-react";

const supplierSchema = z.object({
  name: z.string().min(1, "Supplier name is required"),
  contactName: z.string().optional(),
  email: z.string().email("Invalid email address").optional().or(z.literal("")),
  phone: z.string().optional(),
  address: z.string().optional(),
  notes: z.string().optional(),
});
type SupplierForm = z.infer<typeof supplierSchema>;

export default function Suppliers() {
  const queryClient = useQueryClient();
  const [search, setSearch] = useState("");
  const [addOpen, setAddOpen] = useState(false);
  const [editSupplier, setEditSupplier] = useState<any | null>(null);
  const [deleteId, setDeleteId] = useState<number | null>(null);

  const { data: suppliers, isLoading } = useListSuppliers({
    query: {
      queryKey: getListSuppliersQueryKey({ search: search || undefined }),
      params: { search: search || undefined },
    },
  });

  const createSupplier = useCreateSupplier();
  const updateSupplier = useUpdateSupplier();
  const deleteSupplier = useDeleteSupplier();

  const handleDelete = () => {
    if (deleteId == null) return;
    deleteSupplier.mutate({ id: deleteId }, {
      onSuccess: () => {
        toast.success("Supplier deleted");
        queryClient.invalidateQueries({ queryKey: getListSuppliersQueryKey() });
        setDeleteId(null);
      },
      onError: () => toast.error("Failed to delete supplier"),
    });
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-3xl font-bold tracking-tight">Suppliers</h1>
        <Button size="sm" className="bg-primary text-primary-foreground hover:bg-primary/90" onClick={() => setAddOpen(true)}>
          <Plus className="w-4 h-4 mr-1.5" /> Add Supplier
        </Button>
      </div>

      <div className="flex items-center gap-3 bg-card p-3 rounded-lg border border-border">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input placeholder="Search by name, contact, or email..." className="pl-9 bg-background border-input h-9" value={search} onChange={e => setSearch(e.target.value)} />
        </div>
        <span className="text-xs text-muted-foreground">{suppliers?.length ?? 0} suppliers</span>
      </div>

      <Card className="glass-card overflow-hidden">
        <div className="overflow-x-auto">
          <Table>
            <TableHeader className="bg-muted/50">
              <TableRow className="border-border">
                <TableHead>Supplier</TableHead>
                <TableHead>Contact</TableHead>
                <TableHead>Email</TableHead>
                <TableHead>Phone</TableHead>
                <TableHead>Address</TableHead>
                <TableHead>Added On</TableHead>
                <TableHead className="text-right">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {isLoading ? (
                Array.from({ length: 4 }).map((_, i) => (
                  <TableRow key={i} className="border-border">
                    {Array.from({ length: 7 }).map((_, j) => <TableCell key={j}><Skeleton className="h-4 w-full" /></TableCell>)}
                  </TableRow>
                ))
              ) : suppliers?.length === 0 ? (
                <TableRow><TableCell colSpan={7} className="text-center py-12 text-muted-foreground">No suppliers found</TableCell></TableRow>
              ) : (
                suppliers?.map(s => (
                  <TableRow key={s.id} className="border-border hover:bg-white/5 transition-colors">
                    <TableCell>
                      <p className="font-medium text-sm">{s.name}</p>
                      {s.notes && <p className="text-xs text-muted-foreground truncate max-w-[160px]">{s.notes}</p>}
                    </TableCell>
                    <TableCell className="text-sm text-muted-foreground">{s.contactName || "—"}</TableCell>
                    <TableCell>
                      {s.email ? (
                        <a href={`mailto:${s.email}`} className="flex items-center gap-1 text-sm text-primary hover:underline">
                          <Mail className="w-3 h-3" /> {s.email}
                        </a>
                      ) : <span className="text-muted-foreground">—</span>}
                    </TableCell>
                    <TableCell>
                      {s.phone ? (
                        <span className="flex items-center gap-1 text-sm text-muted-foreground"><Phone className="w-3 h-3" />{s.phone}</span>
                      ) : <span className="text-muted-foreground">—</span>}
                    </TableCell>
                    <TableCell>
                      {s.address ? (
                        <span className="flex items-center gap-1 text-xs text-muted-foreground max-w-[150px] truncate"><MapPin className="w-3 h-3 shrink-0" />{s.address}</span>
                      ) : <span className="text-muted-foreground">—</span>}
                    </TableCell>
                    <TableCell className="text-xs text-muted-foreground font-mono whitespace-nowrap">{formatDate(s.createdAt)}</TableCell>
                    <TableCell className="text-right">
                      <Button variant="ghost" size="icon" className="h-7 w-7 text-muted-foreground hover:text-primary" onClick={() => setEditSupplier(s)}>
                        <Edit2 className="h-3.5 w-3.5" />
                      </Button>
                      <Button variant="ghost" size="icon" className="h-7 w-7 text-muted-foreground hover:text-destructive" onClick={() => setDeleteId(s.id)}>
                        <Trash2 className="h-3.5 w-3.5" />
                      </Button>
                    </TableCell>
                  </TableRow>
                ))
              )}
            </TableBody>
          </Table>
        </div>
      </Card>

      {/* ADD DIALOG */}
      <SupplierFormDialog
        open={addOpen} onClose={() => setAddOpen(false)} isEdit={false}
        onSubmit={(data) => {
          createSupplier.mutate({ data }, {
            onSuccess: () => { toast.success("Supplier added"); queryClient.invalidateQueries({ queryKey: getListSuppliersQueryKey() }); setAddOpen(false); },
            onError: () => toast.error("Failed to add supplier"),
          });
        }}
        isSubmitting={createSupplier.isPending}
      />

      {/* EDIT DIALOG */}
      {editSupplier && (
        <SupplierFormDialog
          open={!!editSupplier} onClose={() => setEditSupplier(null)} isEdit
          defaultValues={{ name: editSupplier.name, contactName: editSupplier.contactName ?? "", email: editSupplier.email ?? "", phone: editSupplier.phone ?? "", address: editSupplier.address ?? "", notes: editSupplier.notes ?? "" }}
          onSubmit={(data) => {
            updateSupplier.mutate({ id: editSupplier.id, data }, {
              onSuccess: () => { toast.success("Supplier updated"); queryClient.invalidateQueries({ queryKey: getListSuppliersQueryKey() }); setEditSupplier(null); },
              onError: () => toast.error("Failed to update supplier"),
            });
          }}
          isSubmitting={updateSupplier.isPending}
        />
      )}

      {/* DELETE CONFIRM */}
      <AlertDialog open={deleteId !== null} onOpenChange={o => !o && setDeleteId(null)}>
        <AlertDialogContent className="bg-card border-border">
          <AlertDialogHeader>
            <AlertDialogTitle>Delete Supplier</AlertDialogTitle>
            <AlertDialogDescription>This will permanently remove this supplier. Existing products linked to this supplier will have their supplier field cleared.</AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel className="border-border">Cancel</AlertDialogCancel>
            <AlertDialogAction className="bg-destructive text-destructive-foreground hover:bg-destructive/90" onClick={handleDelete}>Delete</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}

function SupplierFormDialog({ open, onClose, defaultValues, onSubmit, isSubmitting, isEdit }: {
  open: boolean; onClose: () => void; defaultValues?: Partial<SupplierForm>;
  onSubmit: (data: SupplierForm) => void; isSubmitting: boolean; isEdit: boolean;
}) {
  const { register, handleSubmit, reset, formState: { errors } } = useForm<SupplierForm>({
    resolver: zodResolver(supplierSchema),
    values: defaultValues,
  });

  return (
    <Dialog open={open} onOpenChange={o => { if (!o) { onClose(); reset(); } }}>
      <DialogContent className="bg-card border-border max-w-lg">
        <DialogHeader><DialogTitle>{isEdit ? "Edit Supplier" : "Add Supplier"}</DialogTitle></DialogHeader>
        <form onSubmit={handleSubmit(d => { onSubmit(d); reset(); })} className="space-y-4">
          <div className="space-y-1.5">
            <Label>Company / Supplier Name <span className="text-destructive">*</span></Label>
            <Input {...register("name")} placeholder="e.g. TechSource Inc" className="bg-background border-input" />
            {errors.name && <p className="text-xs text-destructive">{errors.name.message}</p>}
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-1.5">
              <Label>Contact Person</Label>
              <Input {...register("contactName")} placeholder="Full name" className="bg-background border-input" />
            </div>
            <div className="space-y-1.5">
              <Label>Phone</Label>
              <Input {...register("phone")} placeholder="+91-XXXXX-XXXXX" className="bg-background border-input" />
            </div>
          </div>
          <div className="space-y-1.5">
            <Label>Email</Label>
            <Input {...register("email")} type="email" placeholder="contact@supplier.com" className="bg-background border-input" />
            {errors.email && <p className="text-xs text-destructive">{errors.email.message}</p>}
          </div>
          <div className="space-y-1.5">
            <Label>Address</Label>
            <Input {...register("address")} placeholder="Full address" className="bg-background border-input" />
          </div>
          <div className="space-y-1.5">
            <Label>Notes</Label>
            <Input {...register("notes")} placeholder="Additional notes about this supplier" className="bg-background border-input" />
          </div>
          <DialogFooter>
            <Button type="button" variant="outline" onClick={() => { onClose(); reset(); }} className="border-border">Cancel</Button>
            <Button type="submit" disabled={isSubmitting} className="bg-primary text-primary-foreground hover:bg-primary/90">
              {isSubmitting ? "Saving..." : isEdit ? "Save Changes" : "Add Supplier"}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}
