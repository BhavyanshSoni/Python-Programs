import { Router, type IRouter } from "express";
import { eq, and, desc } from "drizzle-orm";
import { db, transactionsTable, productsTable, suppliersTable } from "@workspace/db";
import {
  ListTransactionsQueryParams,
  ListTransactionsResponse,
  CreateTransactionBody,
  GetTransactionParams,
  GetTransactionResponse,
} from "@workspace/api-zod";
import { toISOString, toNum } from "../lib/coerce";

function coerceTx(r: any) {
  return {
    ...r,
    unitPrice: toNum(r.unitPrice),
    totalAmount: toNum(r.totalAmount),
    createdAt: toISOString(r.createdAt) ?? "",
  };
}

const router: IRouter = Router();

const selectTx = {
  id: transactionsTable.id,
  type: transactionsTable.type,
  productId: transactionsTable.productId,
  productName: productsTable.name,
  supplierId: transactionsTable.supplierId,
  supplierName: suppliersTable.name,
  quantity: transactionsTable.quantity,
  unitPrice: transactionsTable.unitPrice,
  totalAmount: transactionsTable.totalAmount,
  referenceNumber: transactionsTable.referenceNumber,
  notes: transactionsTable.notes,
  createdAt: transactionsTable.createdAt,
};

const transactionWithRelations = (filters: any[] = [], limit?: number) => {
  const query = db
    .select(selectTx)
    .from(transactionsTable)
    .leftJoin(productsTable, eq(transactionsTable.productId, productsTable.id))
    .leftJoin(suppliersTable, eq(transactionsTable.supplierId, suppliersTable.id))
    .where(filters.length > 0 ? and(...filters) : undefined)
    .orderBy(desc(transactionsTable.createdAt));

  return limit ? query.limit(limit) : query;
};

router.get("/transactions", async (req, res): Promise<void> => {
  const qp = ListTransactionsQueryParams.safeParse(req.query);
  if (!qp.success) {
    res.status(400).json({ error: qp.error.message });
    return;
  }

  const filters: any[] = [];
  if (qp.data.type) filters.push(eq(transactionsTable.type, qp.data.type as any));
  if (qp.data.supplierId) filters.push(eq(transactionsTable.supplierId, qp.data.supplierId));

  const rows = await transactionWithRelations(filters, qp.data.limit);
  res.json(ListTransactionsResponse.parse(rows.map(coerceTx)));
});

router.post("/transactions", async (req, res): Promise<void> => {
  const parsed = CreateTransactionBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const totalAmount = parsed.data.quantity * parsed.data.unitPrice;

  const [tx] = await db.insert(transactionsTable).values({
    ...parsed.data,
    unitPrice: String(parsed.data.unitPrice),
    totalAmount: String(totalAmount),
  }).returning();

  if (parsed.data.type === "purchase") {
    const [product] = await db.select().from(productsTable).where(eq(productsTable.id, parsed.data.productId));
    if (product) {
      await db.update(productsTable)
        .set({ quantity: product.quantity + parsed.data.quantity, updatedAt: new Date() })
        .where(eq(productsTable.id, parsed.data.productId));
    }
  } else if (parsed.data.type === "sale") {
    const [product] = await db.select().from(productsTable).where(eq(productsTable.id, parsed.data.productId));
    if (product) {
      if (product.quantity < parsed.data.quantity) {
        res.status(400).json({ error: `Insufficient stock. Available: ${product.quantity}` });
        return;
      }
      await db.update(productsTable)
        .set({ quantity: product.quantity - parsed.data.quantity, updatedAt: new Date() })
        .where(eq(productsTable.id, parsed.data.productId));
    }
  }

  const rows = await transactionWithRelations([eq(transactionsTable.id, tx.id)]);
  res.status(201).json(coerceTx(rows[0]));
});

router.get("/transactions/:id", async (req, res): Promise<void> => {
  const params = GetTransactionParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  const rows = await transactionWithRelations([eq(transactionsTable.id, params.data.id)]);
  if (!rows[0]) {
    res.status(404).json({ error: "Transaction not found" });
    return;
  }
  res.json(GetTransactionResponse.parse(coerceTx(rows[0])));
});

export default router;
