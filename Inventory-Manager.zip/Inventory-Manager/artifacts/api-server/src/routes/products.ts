import { Router, type IRouter } from "express";
import { eq, ilike, and, lte, sql, or } from "drizzle-orm";
import { db, productsTable, categoriesTable, suppliersTable } from "@workspace/db";
import {
  ListProductsQueryParams,
  ListProductsResponse,
  CreateProductBody,
  GetProductParams,
  GetProductResponse,
  UpdateProductParams,
  UpdateProductBody,
  UpdateProductResponse,
  DeleteProductParams,
} from "@workspace/api-zod";
import { toISOString, toNum } from "../lib/coerce";

function coerceProduct(r: any) {
  return {
    ...r,
    unitPrice: toNum(r.unitPrice),
    gstPercent: toNum(r.gstPercent, 18),
    createdAt: toISOString(r.createdAt) ?? "",
    updatedAt: toISOString(r.updatedAt),
  };
}

const router: IRouter = Router();

const productWithRelations = async (filters: any[] = []) => {
  return db
    .select({
      id: productsTable.id,
      name: productsTable.name,
      sku: productsTable.sku,
      description: productsTable.description,
      categoryId: productsTable.categoryId,
      categoryName: categoriesTable.name,
      supplierId: productsTable.supplierId,
      supplierName: suppliersTable.name,
      quantity: productsTable.quantity,
      minStockLevel: productsTable.minStockLevel,
      unitPrice: productsTable.unitPrice,
      gstPercent: productsTable.gstPercent,
      imageUrl: productsTable.imageUrl,
      barcode: productsTable.barcode,
      location: productsTable.location,
      createdAt: productsTable.createdAt,
      updatedAt: productsTable.updatedAt,
    })
    .from(productsTable)
    .leftJoin(categoriesTable, eq(productsTable.categoryId, categoriesTable.id))
    .leftJoin(suppliersTable, eq(productsTable.supplierId, suppliersTable.id))
    .where(filters.length > 0 ? and(...filters) : undefined)
    .orderBy(productsTable.name);
};

router.get("/products", async (req, res): Promise<void> => {
  const qp = ListProductsQueryParams.safeParse(req.query);
  if (!qp.success) {
    res.status(400).json({ error: qp.error.message });
    return;
  }

  const filters: any[] = [];
  if (qp.data.search) {
    filters.push(
      or(
        ilike(productsTable.name, `%${qp.data.search}%`),
        ilike(productsTable.sku, `%${qp.data.search}%`),
        ilike(productsTable.description, `%${qp.data.search}%`),
        ilike(productsTable.barcode, `%${qp.data.search}%`)
      )
    );
  }
  if (qp.data.categoryId) {
    filters.push(eq(productsTable.categoryId, qp.data.categoryId));
  }
  if (qp.data.outOfStock) {
    filters.push(eq(productsTable.quantity, 0));
  } else if (qp.data.lowStock) {
    filters.push(lte(productsTable.quantity, productsTable.minStockLevel));
    filters.push(sql`${productsTable.quantity} > 0`);
  }

  const rows = await productWithRelations(filters);
  res.json(ListProductsResponse.parse(rows.map(coerceProduct)));
});

router.post("/products", async (req, res): Promise<void> => {
  const parsed = CreateProductBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  if (parsed.data.quantity !== undefined && parsed.data.quantity < 0) {
    res.status(400).json({ error: "Quantity must be 0 or greater" });
    return;
  }
  if (parsed.data.unitPrice !== undefined && parsed.data.unitPrice <= 0) {
    res.status(400).json({ error: "Unit price must be greater than 0" });
    return;
  }
  if (parsed.data.gstPercent !== undefined && (parsed.data.gstPercent < 0 || parsed.data.gstPercent > 100)) {
    res.status(400).json({ error: "GST must be between 0 and 100" });
    return;
  }

  const [inserted] = await db.insert(productsTable).values({
    ...parsed.data,
    unitPrice: String(parsed.data.unitPrice),
    gstPercent: String(parsed.data.gstPercent ?? 18),
  }).returning();

  const rows = await productWithRelations([eq(productsTable.id, inserted.id)]);
  if (!rows[0]) {
    res.status(500).json({ error: "Failed to retrieve created product" });
    return;
  }
  res.status(201).json(GetProductResponse.parse(coerceProduct(rows[0])));
});

router.get("/products/:id", async (req, res): Promise<void> => {
  const params = GetProductParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  const rows = await productWithRelations([eq(productsTable.id, params.data.id)]);
  if (!rows[0]) {
    res.status(404).json({ error: "Product not found" });
    return;
  }
  res.json(GetProductResponse.parse(coerceProduct(rows[0])));
});

router.patch("/products/:id", async (req, res): Promise<void> => {
  const params = UpdateProductParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  const parsed = UpdateProductBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  if (parsed.data.quantity !== undefined && parsed.data.quantity < 0) {
    res.status(400).json({ error: "Quantity must be 0 or greater" });
    return;
  }
  if (parsed.data.unitPrice !== undefined && parsed.data.unitPrice <= 0) {
    res.status(400).json({ error: "Unit price must be greater than 0" });
    return;
  }

  const updateData: any = { ...parsed.data, updatedAt: new Date() };
  if (updateData.unitPrice !== undefined) updateData.unitPrice = String(updateData.unitPrice);
  if (updateData.gstPercent !== undefined) updateData.gstPercent = String(updateData.gstPercent);

  const [updated] = await db.update(productsTable)
    .set(updateData)
    .where(eq(productsTable.id, params.data.id))
    .returning();

  if (!updated) {
    res.status(404).json({ error: "Product not found" });
    return;
  }

  const rows = await productWithRelations([eq(productsTable.id, params.data.id)]);
  res.json(UpdateProductResponse.parse(coerceProduct(rows[0])));
});

router.delete("/products/:id", async (req, res): Promise<void> => {
  const params = DeleteProductParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  const [row] = await db.delete(productsTable).where(eq(productsTable.id, params.data.id)).returning();
  if (!row) {
    res.status(404).json({ error: "Product not found" });
    return;
  }
  res.sendStatus(204);
});

export default router;
