import { Router, type IRouter } from "express";
import { eq, ilike, or } from "drizzle-orm";
import { db, suppliersTable } from "@workspace/db";
import {
  ListSuppliersQueryParams,
  ListSuppliersResponse,
  CreateSupplierBody,
  GetSupplierParams,
  GetSupplierResponse,
  UpdateSupplierParams,
  UpdateSupplierBody,
  UpdateSupplierResponse,
  DeleteSupplierParams,
} from "@workspace/api-zod";
import { toISOString } from "../lib/coerce";

const coerceSupplier = (r: any) => ({ ...r, createdAt: toISOString(r.createdAt) ?? "" });

const router: IRouter = Router();

router.get("/suppliers", async (req, res): Promise<void> => {
  const qp = ListSuppliersQueryParams.safeParse(req.query);
  const search = qp.success ? qp.data.search : undefined;

  let rows;
  if (search) {
    rows = await db.select().from(suppliersTable).where(
      or(
        ilike(suppliersTable.name, `%${search}%`),
        ilike(suppliersTable.contactName, `%${search}%`),
        ilike(suppliersTable.email, `%${search}%`)
      )
    ).orderBy(suppliersTable.name);
  } else {
    rows = await db.select().from(suppliersTable).orderBy(suppliersTable.name);
  }
  res.json(ListSuppliersResponse.parse(rows.map(coerceSupplier)));
});

router.post("/suppliers", async (req, res): Promise<void> => {
  const parsed = CreateSupplierBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  const [row] = await db.insert(suppliersTable).values(parsed.data).returning();
  res.status(201).json(GetSupplierResponse.parse(coerceSupplier(row)));
});

router.get("/suppliers/:id", async (req, res): Promise<void> => {
  const params = GetSupplierParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  const [row] = await db.select().from(suppliersTable).where(eq(suppliersTable.id, params.data.id));
  if (!row) {
    res.status(404).json({ error: "Supplier not found" });
    return;
  }
  res.json(GetSupplierResponse.parse(coerceSupplier(row)));
});

router.patch("/suppliers/:id", async (req, res): Promise<void> => {
  const params = UpdateSupplierParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  const parsed = UpdateSupplierBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  const [row] = await db.update(suppliersTable).set(parsed.data).where(eq(suppliersTable.id, params.data.id)).returning();
  if (!row) {
    res.status(404).json({ error: "Supplier not found" });
    return;
  }
  res.json(UpdateSupplierResponse.parse(coerceSupplier(row)));
});

router.delete("/suppliers/:id", async (req, res): Promise<void> => {
  const params = DeleteSupplierParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  const [row] = await db.delete(suppliersTable).where(eq(suppliersTable.id, params.data.id)).returning();
  if (!row) {
    res.status(404).json({ error: "Supplier not found" });
    return;
  }
  res.sendStatus(204);
});

export default router;
