import { Router, type IRouter } from "express";
import { eq, sql, lte, and, gt, sum, count, desc } from "drizzle-orm";
import { db, productsTable, categoriesTable, suppliersTable, transactionsTable, inventoryMovementsTable } from "@workspace/db";

const router: IRouter = Router();

router.get("/dashboard/stats", async (_req, res): Promise<void> => {
  const [productStats] = await db
    .select({
      totalProducts: count(productsTable.id),
      totalItems: sql<number>`coalesce(sum(${productsTable.quantity}), 0)`,
      totalValue: sql<number>`coalesce(sum(${productsTable.quantity} * ${productsTable.unitPrice}::numeric), 0)`,
      lowStockCount: sql<number>`count(case when ${productsTable.quantity} > 0 and ${productsTable.quantity} <= ${productsTable.minStockLevel} then 1 end)`,
      outOfStockCount: sql<number>`count(case when ${productsTable.quantity} = 0 then 1 end)`,
    })
    .from(productsTable);

  const [supplierStats] = await db
    .select({ totalSuppliers: count(suppliersTable.id) })
    .from(suppliersTable);

  const [txStats] = await db
    .select({
      totalTransactions: count(transactionsTable.id),
      purchaseValue: sql<number>`coalesce(sum(case when ${transactionsTable.type} = 'purchase' then ${transactionsTable.totalAmount}::numeric else 0 end), 0)`,
      salesValue: sql<number>`coalesce(sum(case when ${transactionsTable.type} = 'sale' then ${transactionsTable.totalAmount}::numeric else 0 end), 0)`,
    })
    .from(transactionsTable);

  res.json({
    totalProducts: Number(productStats?.totalProducts ?? 0),
    totalItems: Number(productStats?.totalItems ?? 0),
    totalValue: Number(productStats?.totalValue ?? 0),
    lowStockCount: Number(productStats?.lowStockCount ?? 0),
    outOfStockCount: Number(productStats?.outOfStockCount ?? 0),
    totalSuppliers: Number(supplierStats?.totalSuppliers ?? 0),
    totalTransactions: Number(txStats?.totalTransactions ?? 0),
    purchaseValue: Number(txStats?.purchaseValue ?? 0),
    salesValue: Number(txStats?.salesValue ?? 0),
  });
});

router.get("/dashboard/recent-activity", async (req, res): Promise<void> => {
  const limit = parseInt(String(req.query.limit ?? "20"), 10) || 20;

  const movements = await db
    .select({
      id: inventoryMovementsTable.id,
      type: inventoryMovementsTable.movementType,
      productName: productsTable.name,
      quantity: inventoryMovementsTable.quantity,
      reason: inventoryMovementsTable.reason,
      createdAt: inventoryMovementsTable.createdAt,
    })
    .from(inventoryMovementsTable)
    .leftJoin(productsTable, eq(inventoryMovementsTable.productId, productsTable.id))
    .orderBy(desc(inventoryMovementsTable.createdAt))
    .limit(limit);

  const activity = movements.map((m) => ({
    id: m.id,
    type: m.type,
    description: m.type === "stock_in"
      ? `Stock added: ${m.productName}`
      : m.type === "stock_out"
      ? `Stock removed: ${m.productName}`
      : `Adjustment: ${m.productName}`,
    productName: m.productName,
    quantity: m.quantity,
    createdAt: m.createdAt,
  }));

  res.json(activity);
});

router.get("/dashboard/stock-value-trend", async (_req, res): Promise<void> => {
  const rows = await db
    .select({
      date: sql<string>`date_trunc('day', ${transactionsTable.createdAt})::date`,
      purchases: sql<number>`coalesce(sum(case when ${transactionsTable.type} = 'purchase' then ${transactionsTable.totalAmount}::numeric else 0 end), 0)`,
      sales: sql<number>`coalesce(sum(case when ${transactionsTable.type} = 'sale' then ${transactionsTable.totalAmount}::numeric else 0 end), 0)`,
    })
    .from(transactionsTable)
    .groupBy(sql`date_trunc('day', ${transactionsTable.createdAt})::date`)
    .orderBy(sql`date_trunc('day', ${transactionsTable.createdAt})::date`)
    .limit(30);

  const trend = rows.map((r) => ({
    date: String(r.date),
    value: Number(r.purchases) - Number(r.sales),
  }));

  if (trend.length === 0) {
    const today = new Date();
    const fakeData = Array.from({ length: 14 }, (_, i) => {
      const d = new Date(today);
      d.setDate(d.getDate() - (13 - i));
      return { date: d.toISOString().split("T")[0], value: 0 };
    });
    res.json(fakeData);
    return;
  }

  res.json(trend);
});

router.get("/dashboard/category-breakdown", async (_req, res): Promise<void> => {
  const rows = await db
    .select({
      categoryName: sql<string>`coalesce(${categoriesTable.name}, 'Uncategorized')`,
      color: categoriesTable.color,
      productCount: count(productsTable.id),
      totalValue: sql<number>`coalesce(sum(${productsTable.quantity} * ${productsTable.unitPrice}::numeric), 0)`,
      totalQuantity: sql<number>`coalesce(sum(${productsTable.quantity}), 0)`,
    })
    .from(productsTable)
    .leftJoin(categoriesTable, eq(productsTable.categoryId, categoriesTable.id))
    .groupBy(categoriesTable.name, categoriesTable.color)
    .orderBy(sql`sum(${productsTable.quantity} * ${productsTable.unitPrice}::numeric) desc`);

  res.json(rows.map((r) => ({
    categoryName: r.categoryName,
    color: r.color,
    productCount: Number(r.productCount),
    totalValue: Number(r.totalValue),
    totalQuantity: Number(r.totalQuantity),
  })));
});

export default router;
