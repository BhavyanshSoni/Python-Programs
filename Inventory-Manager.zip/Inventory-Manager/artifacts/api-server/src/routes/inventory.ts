import { Router, type IRouter } from "express";
import { eq, and, desc } from "drizzle-orm";
import { db, inventoryMovementsTable, productsTable } from "@workspace/db";
import {
  ListInventoryMovementsQueryParams,
  ListInventoryMovementsResponse,
  CreateInventoryMovementBody,
} from "@workspace/api-zod";
import { toISOString } from "../lib/coerce";

const coerceMovement = (r: any) => ({ ...r, createdAt: toISOString(r.createdAt) ?? "" });

const router: IRouter = Router();

const selectMovement = {
  id: inventoryMovementsTable.id,
  productId: inventoryMovementsTable.productId,
  productName: productsTable.name,
  movementType: inventoryMovementsTable.movementType,
  quantity: inventoryMovementsTable.quantity,
  previousQuantity: inventoryMovementsTable.previousQuantity,
  newQuantity: inventoryMovementsTable.newQuantity,
  reason: inventoryMovementsTable.reason,
  notes: inventoryMovementsTable.notes,
  createdAt: inventoryMovementsTable.createdAt,
};

router.get("/inventory/movements", async (req, res): Promise<void> => {
  const qp = ListInventoryMovementsQueryParams.safeParse(req.query);
  if (!qp.success) {
    res.status(400).json({ error: qp.error.message });
    return;
  }

  const filters: any[] = [];
  if (qp.data.productId) filters.push(eq(inventoryMovementsTable.productId, qp.data.productId));
  if (qp.data.movementType) filters.push(eq(inventoryMovementsTable.movementType, qp.data.movementType as any));

  const query = db
    .select(selectMovement)
    .from(inventoryMovementsTable)
    .leftJoin(productsTable, eq(inventoryMovementsTable.productId, productsTable.id))
    .where(filters.length > 0 ? and(...filters) : undefined)
    .orderBy(desc(inventoryMovementsTable.createdAt));

  const rows = qp.data.limit ? await query.limit(qp.data.limit) : await query;
  res.json(ListInventoryMovementsResponse.parse(rows.map(coerceMovement)));
});

router.post("/inventory/movements", async (req, res): Promise<void> => {
  const parsed = CreateInventoryMovementBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const [product] = await db.select().from(productsTable).where(eq(productsTable.id, parsed.data.productId));
  if (!product) {
    res.status(404).json({ error: "Product not found" });
    return;
  }

  const previousQuantity = product.quantity;
  let newQuantity: number;

  if (parsed.data.movementType === "stock_in") {
    newQuantity = previousQuantity + parsed.data.quantity;
  } else if (parsed.data.movementType === "stock_out") {
    newQuantity = previousQuantity - parsed.data.quantity;
    if (newQuantity < 0) {
      res.status(400).json({ error: `Insufficient stock. Current quantity: ${previousQuantity}` });
      return;
    }
  } else {
    newQuantity = parsed.data.quantity;
  }

  await db.update(productsTable)
    .set({ quantity: newQuantity, updatedAt: new Date() })
    .where(eq(productsTable.id, parsed.data.productId));

  const [movement] = await db.insert(inventoryMovementsTable).values({
    ...parsed.data,
    previousQuantity,
    newQuantity,
  }).returning();

  const [withProduct] = await db
    .select(selectMovement)
    .from(inventoryMovementsTable)
    .leftJoin(productsTable, eq(inventoryMovementsTable.productId, productsTable.id))
    .where(eq(inventoryMovementsTable.id, movement.id));

  res.status(201).json(coerceMovement(withProduct));
});

export default router;
