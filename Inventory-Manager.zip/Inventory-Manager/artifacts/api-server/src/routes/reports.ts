import { Router, type IRouter } from "express";
import { eq, lte, sql, count, sum, desc } from "drizzle-orm";
import { db, productsTable, categoriesTable, suppliersTable, transactionsTable } from "@workspace/db";

const router: IRouter = Router();

router.get("/reports/low-stock", async (_req, res): Promise<void> => {
  const rows = await db
    .select({
      id: productsTable.id,
      name: productsTable.name,
      sku: productsTable.sku,
      description: productsTable.description,
      categoryId: productsTable.categoryId,
      categoryName: categoriesTable.name,
      supplierId: productsTable.supplierId,
      supplierName: suppliersTable.name,
      quantity: productsTable.quantity,
      minStockLevel: productsTable.minStockLevel,
      unitPrice: productsTable.unitPrice,
      imageUrl: productsTable.imageUrl,
      barcode: productsTable.barcode,
      location: productsTable.location,
      createdAt: productsTable.createdAt,
      updatedAt: productsTable.updatedAt,
    })
    .from(productsTable)
    .leftJoin(categoriesTable, eq(productsTable.categoryId, categoriesTable.id))
    .leftJoin(suppliersTable, eq(productsTable.supplierId, suppliersTable.id))
    .where(lte(productsTable.quantity, productsTable.minStockLevel))
    .orderBy(productsTable.quantity);

  res.json(rows);
});

router.get("/reports/inventory-value", async (_req, res): Promise<void> => {
  const rows = await db
    .select({
      categoryName: sql<string>`coalesce(${categoriesTable.name}, 'Uncategorized')`,
      totalValue: sql<number>`coalesce(sum(${productsTable.quantity} * ${productsTable.unitPrice}::numeric), 0)`,
      productCount: count(productsTable.id),
    })
    .from(productsTable)
    .leftJoin(categoriesTable, eq(productsTable.categoryId, categoriesTable.id))
    .groupBy(categoriesTable.name)
    .orderBy(sql`sum(${productsTable.quantity} * ${productsTable.unitPrice}::numeric) desc`);

  const grandTotal = rows.reduce((acc, r) => acc + Number(r.totalValue), 0);

  const result = rows.map((r) => ({
    categoryName: r.categoryName,
    totalValue: Number(r.totalValue),
    productCount: Number(r.productCount),
    percentage: grandTotal > 0 ? Math.round((Number(r.totalValue) / grandTotal) * 100) : 0,
  }));

  res.json(result);
});

router.get("/reports/top-products", async (req, res): Promise<void> => {
  const limit = parseInt(String(req.query.limit ?? "10"), 10) || 10;

  const rows = await db
    .select({
      productId: transactionsTable.productId,
      productName: productsTable.name,
      sku: productsTable.sku,
      totalTransactions: count(transactionsTable.id),
      totalQuantity: sql<number>`coalesce(sum(${transactionsTable.quantity}), 0)`,
      totalRevenue: sql<number>`coalesce(sum(${transactionsTable.totalAmount}::numeric), 0)`,
    })
    .from(transactionsTable)
    .leftJoin(productsTable, eq(transactionsTable.productId, productsTable.id))
    .groupBy(transactionsTable.productId, productsTable.name, productsTable.sku)
    .orderBy(sql`sum(${transactionsTable.totalAmount}::numeric) desc`)
    .limit(limit);

  res.json(rows.map((r) => ({
    productId: r.productId,
    productName: r.productName ?? "Unknown",
    sku: r.sku ?? "",
    totalTransactions: Number(r.totalTransactions),
    totalQuantity: Number(r.totalQuantity),
    totalRevenue: Number(r.totalRevenue),
  })));
});

export default router;
